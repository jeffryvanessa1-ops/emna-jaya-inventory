<?php
require_once dirname(__DIR__) . '/includes/layout.php';
require_role(['Admin', 'Manajer']);
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $items = json_decode($_POST['items_json'] ?? '[]', true) ?: [];
    if (!$items) {
        flash('danger', 'Tambahkan minimal satu item pembelian.');
        redirect('purchases.php');
    }
    $pdo->beginTransaction();
    $invoice = next_invoice_no($pdo, 'purchases', 'PO');
    $subtotal = 0;
    foreach ($items as $item) {
        $subtotal += (float)$item['qty'] * (float)$item['cost_price'];
    }
    $discount = (float)($_POST['discount'] ?? 0);
    $total = max(0, $subtotal - $discount);
    $status = $_POST['status'] === 'received' ? 'received' : 'ordered';
    $pdo->prepare('INSERT INTO purchases (supplier_id, invoice_no, purchase_date, status, subtotal, discount, total, notes, created_by) VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?)')
        ->execute([$_POST['supplier_id'] ?: null, $invoice, $_POST['purchase_date'], $status, $subtotal, $discount, $total, trim($_POST['notes'] ?? ''), $_SESSION['user']['id']]);
    $purchaseId = (int)$pdo->lastInsertId();
    foreach ($items as $item) {
        $stmt = $pdo->prepare('SELECT * FROM products WHERE id=?');
        $stmt->execute([(int)$item['product_id']]);
        $product = $stmt->fetch();
        $unit = $item['unit_name'] ?: $product['base_unit'];
        $multiplier = product_unit_multiplier($product, $unit);
        $baseQty = (float)$item['qty'] * $multiplier;
        $lineTotal = (float)$item['qty'] * (float)$item['cost_price'];
        $pdo->prepare('INSERT INTO purchase_items (purchase_id, product_id, unit_name, unit_multiplier, qty, base_qty, cost_price, total) VALUES (?, ?, ?, ?, ?, ?, ?, ?)')
            ->execute([$purchaseId, $product['id'], $unit, $multiplier, $item['qty'], $baseQty, $item['cost_price'], $lineTotal]);
        if ($status === 'received') {
            add_stock_movement($pdo, (int)$product['id'], 'purchase', $baseQty, 'purchase', $purchaseId, $invoice);
        }
    }
    $pdo->commit();
    flash('success', 'Pembelian disimpan sebagai ' . $invoice . '.');
    redirect('purchases.php');
}

$suppliers = $pdo->query('SELECT * FROM suppliers ORDER BY name')->fetchAll();
$products = $pdo->query('SELECT * FROM products WHERE is_active=1 ORDER BY name')->fetchAll();
$purchases = $pdo->query('SELECT p.*, s.name AS supplier_name FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id ORDER BY p.purchase_date DESC, p.id DESC LIMIT 100')->fetchAll();
page_header('Pembelian');
?>
<div class="panel mb-4">
    <div class="panel-head"><h2>Buat Pesanan Pembelian / Penerimaan Barang</h2></div>
    <form method="post" id="purchaseForm">
        <input type="hidden" name="items_json" id="purchaseItemsJson">
        <div class="row g-3">
            <label class="col-md-3">Pemasok<select class="form-select" name="supplier_id"><option value="">Tanpa pemasok</option><?php foreach ($suppliers as $s): ?><option value="<?= $s['id'] ?>"><?= e($s['name']) ?></option><?php endforeach; ?></select></label>
            <label class="col-md-2">Tanggal<input class="form-control" type="date" name="purchase_date" value="<?= date('Y-m-d') ?>"></label>
            <label class="col-md-2">Status<select class="form-select" name="status"><option value="ordered">Dipesan</option><option value="received">Diterima</option></select></label>
            <label class="col-md-2">Diskon<input class="form-control" type="number" step="0.01" name="discount" value="0"></label>
            <label class="col-md-3">Catatan<input class="form-control" name="notes"></label>
        </div>
        <div class="row g-2 mt-3 align-items-end">
            <label class="col-md-4">Produk<select class="form-select" id="purchaseProduct"><?php foreach ($products as $p): ?><option value="<?= $p['id'] ?>" data-name="<?= e($p['name']) ?>" data-cost="<?= $p['cost_price'] ?>" data-base="<?= e($p['base_unit']) ?>" data-u1="<?= e($p['unit_1_name']) ?>" data-u2="<?= e($p['unit_2_name']) ?>"><?= e($p['sku'] . ' - ' . $p['name']) ?></option><?php endforeach; ?></select></label>
            <label class="col-md-2">Satuan<select class="form-select" id="purchaseUnit"></select></label>
            <label class="col-md-2">Jumlah<input class="form-control" id="purchaseQty" type="number" step="0.01" value="1"></label>
            <label class="col-md-2">Modal<input class="form-control" id="purchaseCost" type="number" step="0.01"></label>
            <div class="col-md-2"><button type="button" class="btn btn-dark w-100" id="addPurchaseItem">Tambah</button></div>
        </div>
        <div class="table-responsive mt-3">
            <table class="table" id="purchaseItemsTable"><thead><tr><th>Produk</th><th>Satuan</th><th class="text-end">Jumlah</th><th class="text-end">Modal</th><th class="text-end">Total</th><th></th></tr></thead><tbody></tbody></table>
        </div>
        <div class="text-end"><strong>Total: <span id="purchaseTotal">Rp 0</span></strong> <button class="btn btn-dark ms-3">Simpan Pembelian</button></div>
    </form>
</div>
<div class="panel">
    <div class="panel-head"><h2>Riwayat Pembelian</h2><a class="btn btn-sm btn-outline-dark" href="export.php?type=purchases">Excel</a></div>
    <table class="table align-middle"><thead><tr><th>Faktur</th><th>Tanggal</th><th>Pemasok</th><th>Status</th><th class="text-end">Total</th></tr></thead><tbody>
    <?php foreach ($purchases as $p): ?><tr><td><?= e($p['invoice_no']) ?></td><td><?= e($p['purchase_date']) ?></td><td><?= e($p['supplier_name']) ?></td><td><span class="badge text-bg-dark"><?= e(purchase_status_label($p['status'])) ?></span></td><td class="text-end"><?= money($p['total']) ?></td></tr><?php endforeach; ?>
    </tbody></table>
</div>
<?php page_footer(); ?>
