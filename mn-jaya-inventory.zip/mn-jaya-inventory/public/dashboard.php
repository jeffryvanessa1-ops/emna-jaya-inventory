<?php
require_once dirname(__DIR__) . '/includes/layout.php';
require_login();

$pdo = db();
$todaySales = $pdo->query("SELECT COALESCE(SUM(total),0) FROM sales WHERE DATE(sale_date)=CURDATE() AND status <> 'void'")->fetchColumn();
$monthSales = $pdo->query("SELECT COALESCE(SUM(total),0) FROM sales WHERE DATE_FORMAT(sale_date,'%Y-%m')=DATE_FORMAT(CURDATE(),'%Y-%m') AND status <> 'void'")->fetchColumn();
$products = $pdo->query('SELECT COUNT(*) FROM products WHERE is_active=1')->fetchColumn();
$lowStock = $pdo->query('SELECT COUNT(*) FROM products WHERE is_active=1 AND stock_qty <= min_stock')->fetchColumn();
$receivables = $pdo->query("SELECT COALESCE(SUM(outstanding_amount),0) FROM sales WHERE outstanding_amount > 0 AND status <> 'void'")->fetchColumn();
$recentSales = $pdo->query('SELECT invoice_no, sale_date, total, status FROM sales ORDER BY sale_date DESC LIMIT 8')->fetchAll();
$lowItems = $pdo->query('SELECT sku, name, stock_qty, min_stock, base_unit FROM products WHERE is_active=1 AND stock_qty <= min_stock ORDER BY stock_qty ASC LIMIT 8')->fetchAll();

page_header('Dasbor');
?>
<section class="metric-grid">
    <div class="metric"><span>Penjualan Hari Ini</span><strong><?= money($todaySales) ?></strong></div>
    <div class="metric"><span>Penjualan Bulanan</span><strong><?= money($monthSales) ?></strong></div>
    <div class="metric"><span>Total Produk</span><strong><?= (int)$products ?></strong></div>
    <div class="metric"><span>Stok Rendah</span><strong><?= (int)$lowStock ?></strong></div>
    <div class="metric"><span>Piutang</span><strong><?= money($receivables) ?></strong></div>
</section>

<div class="row g-4 mt-1">
    <div class="col-xl-7">
        <div class="panel">
            <div class="panel-head"><h2>Penjualan Terbaru</h2><a href="reports.php" class="btn btn-sm btn-outline-dark">Laporan</a></div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead><tr><th>Invoice</th><th>Tanggal</th><th>Status</th><th class="text-end">Total</th></tr></thead>
                    <tbody>
                    <?php foreach ($recentSales as $row): ?>
                        <tr>
                            <td><?= e($row['invoice_no']) ?></td>
                            <td><?= e(date('d M Y H:i', strtotime($row['sale_date']))) ?></td>
                            <td><span class="badge text-bg-dark"><?= e(sale_status_label($row['status'])) ?></span></td>
                            <td class="text-end"><?= money($row['total']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$recentSales): ?><tr><td colspan="4" class="text-muted">Belum ada penjualan.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
    <div class="col-xl-5">
        <div class="panel">
            <div class="panel-head"><h2>Produk Stok Rendah</h2><a href="products.php" class="btn btn-sm btn-dark">Kelola</a></div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead><tr><th>SKU</th><th>Produk</th><th class="text-end">Stok</th></tr></thead>
                    <tbody>
                    <?php foreach ($lowItems as $row): ?>
                        <tr>
                            <td><?= e($row['sku']) ?></td>
                            <td><?= e($row['name']) ?></td>
                            <td class="text-end"><?= (float)$row['stock_qty'] ?> <?= e($row['base_unit']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    <?php if (!$lowItems): ?><tr><td colspan="3" class="text-muted">Level stok aman.</td></tr><?php endif; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php page_footer(); ?>
