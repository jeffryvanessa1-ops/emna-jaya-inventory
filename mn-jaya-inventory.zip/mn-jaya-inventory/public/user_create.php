<?php

require_once dirname(__DIR__) . '/includes/layout.php';

require_role(['Admin']);

$roles = db()->query("
    SELECT *
    FROM roles
    ORDER BY name
")->fetchAll();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        $name = trim($_POST['name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $password = $_POST['password'] ?? '';
        $roleId = (int)($_POST['role_id'] ?? 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if (
            $name === '' ||
            $username === '' ||
            $password === '' ||
            $roleId <= 0
        ) {
            throw new Exception('Semua field wajib diisi.');
        }

        $hash = password_hash(
            $password,
            PASSWORD_DEFAULT
        );

        $stmt = db()->prepare("
            INSERT INTO users
            (
                role_id,
                name,
                username,
                password_hash,
                is_active
            )
            VALUES
            (
                ?, ?, ?, ?, ?
            )
        ");

        $stmt->execute([
            $roleId,
            $name,
            $username,
            $hash,
            $isActive
        ]);

        flash(
            'success',
            'Pengguna berhasil ditambahkan.'
        );

        redirect('users.php');

    } catch (Throwable $e) {

        $error = $e->getMessage();

    }
}

page_header('Tambah Pengguna');

?>

<div class="card">

<div class="card-header">
<h5>Tambah Pengguna</h5>
</div>

<div class="card-body">

<?php if($error): ?>

<div class="alert alert-danger">
<?= e($error) ?>
</div>

<?php endif; ?>

<form method="post">

<div class="mb-3">

<label class="form-label">
Nama
</label>

<input
type="text"
name="name"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Username
</label>

<input
type="text"
name="username"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Password
</label>

<input
type="password"
name="password"
class="form-control"
required>

</div>

<div class="mb-3">

<label class="form-label">
Role
</label>

<select
name="role_id"
class="form-select"
required>

<option value="">
Pilih Role
</option>

<?php foreach($roles as $role): ?>

<option value="<?= $role['id'] ?>">
<?= e($role['name']) ?>
</option>

<?php endforeach; ?>

</select>

</div>

<div class="form-check mb-3">

<input
type="checkbox"
name="is_active"
class="form-check-input"
checked>

<label class="form-check-label">

Aktif

</label>

</div>

<button
type="submit"
class="btn btn-primary">

Simpan

</button>

<a
href="users.php"
class="btn btn-secondary">

Kembali

</a>

</form>

</div>

</div>

<?php page_footer(); ?>
