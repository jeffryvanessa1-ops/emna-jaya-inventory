<?php

require_once dirname(__DIR__) . '/includes/layout.php';

require_role(['Admin']);

$users = db()->query("
    SELECT
        u.*,
        r.name AS role_name
    FROM users u
    LEFT JOIN roles r
        ON r.id = u.role_id
    ORDER BY u.id
")->fetchAll();

page_header('Pengguna');
?>

<div class="card">

<div class="card-header d-flex justify-content-between">

<h5>Manajemen Pengguna</h5>

<a href="user_create.php" class="btn btn-primary">
Tambah Pengguna
</a>

</div>

<div class="card-body">

<table class="table table-striped">

<thead>

<tr>
<th>ID</th>
<th>Nama</th>
<th>Username</th>
<th>Role</th>
<th>Status</th>
<th>Aksi</th>
</tr>

</thead>

<tbody>

<?php foreach($users as $user): ?>

<tr>

<td><?= $user['id'] ?></td>

<td><?= e($user['name']) ?></td>

<td><?= e($user['username']) ?></td>

<td><?= e($user['role_name']) ?></td>

<td>
<?= $user['is_active'] ? 'Aktif' : 'Nonaktif' ?>
</td>

<td>

<a href="user_edit.php?id=<?= $user['id'] ?>"
class="btn btn-warning btn-sm">
Edit </a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>

<?php page_footer(); ?>
