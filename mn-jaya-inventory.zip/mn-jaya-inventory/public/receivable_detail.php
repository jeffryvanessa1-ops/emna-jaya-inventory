<?php

require_once dirname(__DIR__) . '/includes/layout.php';

require_login();

$id = (int)($_GET['id'] ?? 0);

$stmt = db()->prepare("
SELECT *
FROM customers
WHERE id=?
");

$stmt->execute([$id]);

$customer = $stmt->fetch();

$sales = db()->prepare("
SELECT *
FROM sales
WHERE customer_id=?
AND outstanding_amount > 0
ORDER BY sale_date DESC
");

$sales->execute([$id]);

$list = $sales->fetchAll();

page_header('Detail Piutang');

?>

<div class="card">

<div class="card-header">

<h5>
<?= e($customer['name']) ?>
</h5>

</div>

<div class="card-body">

<table class="table table-bordered">

<thead>

<tr>

<th>Invoice</th>
<th>Tanggal</th>
<th>Total</th>
<th>Terbayar</th>
<th>Sisa</th>
<th></th>

</tr>

</thead>

<tbody>

<?php foreach($list as $sale): ?>

<tr>

<td><?= e($sale['invoice_no']) ?></td>

<td><?= date('d/m/Y',strtotime($sale['sale_date'])) ?></td>

<td><?= money($sale['total']) ?></td>

<td><?= money($sale['paid_amount']) ?></td>

<td>
<strong class="text-danger">
<?= money($sale['outstanding_amount']) ?>
</strong>
</td>

<td>

<a
href="pay_receivable.php?id=<?= $sale['id'] ?>"
class="btn btn-success btn-sm">

Bayar

</a>

</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>

<?php page_footer(); ?>