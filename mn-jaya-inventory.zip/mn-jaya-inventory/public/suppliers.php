<?php
require_once dirname(__DIR__) . '/includes/layout.php';
require_role(['Admin', 'Manajer']);
$pdo = db();
$edit = null;
if (isset($_GET['delete'])) {
    $pdo->prepare('DELETE FROM suppliers WHERE id=?')->execute([(int)$_GET['delete']]);
    flash('success', 'Pemasok dihapus.');
    redirect('suppliers.php');
}
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM suppliers WHERE id=?');
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [trim($_POST['name']), trim($_POST['phone']), trim($_POST['email']), trim($_POST['address'])];
    if (!empty($_POST['id'])) {
        $pdo->prepare('UPDATE suppliers SET name=?, phone=?, email=?, address=? WHERE id=?')->execute([...$data, (int)$_POST['id']]);
    } else {
        $pdo->prepare('INSERT INTO suppliers (name, phone, email, address) VALUES (?, ?, ?, ?)')->execute($data);
    }
    flash('success', 'Pemasok disimpan.');
    redirect('suppliers.php');
}
$rows = $pdo->query('SELECT * FROM suppliers ORDER BY name')->fetchAll();
page_header('Pemasok');
?>
<div class="row g-4">
    <div class="col-lg-4"><div class="panel"><div class="panel-head"><h2><?= $edit ? 'Ubah Pemasok' : 'Tambah Pemasok' ?></h2></div>
        <form method="post" class="stacked-form">
            <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
            <label>Nama<input class="form-control" name="name" required value="<?= e($edit['name'] ?? '') ?>"></label>
            <label>Telepon<input class="form-control" name="phone" value="<?= e($edit['phone'] ?? '') ?>"></label>
            <label>Email<input class="form-control" name="email" type="email" value="<?= e($edit['email'] ?? '') ?>"></label>
            <label>Alamat<textarea class="form-control" name="address"><?= e($edit['address'] ?? '') ?></textarea></label>
            <button class="btn btn-dark">Simpan Pemasok</button>
        </form></div></div>
    <div class="col-lg-8"><div class="panel"><div class="panel-head"><h2>Daftar Pemasok</h2></div>
        <table class="table align-middle"><thead><tr><th>Nama</th><th>Telepon</th><th>Email</th><th></th></tr></thead><tbody>
        <?php foreach ($rows as $r): ?><tr><td><?= e($r['name']) ?></td><td><?= e($r['phone']) ?></td><td><?= e($r['email']) ?></td><td class="text-end"><a class="btn btn-sm btn-outline-dark" href="?edit=<?= $r['id'] ?>">Ubah</a> <a class="btn btn-sm btn-outline-danger" href="?delete=<?= $r['id'] ?>" data-confirm="Hapus pemasok?">Hapus</a></td></tr><?php endforeach; ?>
        </tbody></table></div></div>
</div>
<?php page_footer(); ?>
