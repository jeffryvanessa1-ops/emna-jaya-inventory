<?php

require_once dirname(__DIR__) . '/includes/auth.php';

require_login();

$id = (int)($_GET['id'] ?? 0);

if ($id > 0) {

    db()->prepare("
        UPDATE sales
        SET
            status = 'void',
            updated_at = NOW()
        WHERE id = ?
    ")->execute([$id]);

}

flash('success', 'Piutang berhasil dihapus');

redirect('receivables.php');