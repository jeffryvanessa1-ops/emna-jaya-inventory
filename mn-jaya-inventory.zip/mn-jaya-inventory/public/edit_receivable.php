<?php

require_once dirname(__DIR__) . '/includes/layout.php';

require_login();

$pdo = db();

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
    SELECT *
    FROM sales
    WHERE id = ?
");

$stmt->execute([$id]);

$sale = $stmt->fetch();

if (!$sale) {
    exit('Data tidak ditemukan');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $total = (float)$_POST['total'];
    $paid = (float)$_POST['paid_amount'];

    $outstanding = max(
        0,
        $total - $paid
    );

    $status =
        $outstanding <= 0
            ? 'paid'
            : 'credit';

    $pdo->prepare("
        UPDATE sales
        SET
            total = ?,
            paid_amount = ?,
            outstanding_amount = ?,
            status = ?,
            updated_at = NOW()
        WHERE id = ?
    ")->execute([
        $total,
        $paid,
        $outstanding,
        $status,
        $id
    ]);

    flash(
        'success',
        'Piutang berhasil diperbarui'
    );

    redirect('receivables.php');
}

page_header('Edit Piutang');
?>

<div class="card">

<div class="card-header">
<h5>Edit Piutang</h5>
</div>

<div class="card-body">

<form method="post">

<div class="mb-3">
<label>Total Hutang</label>

<input
type="number"
step="1"
name="total"
class="form-control"
value="<?= $sale['total'] ?>"
required>
</div>

<div class="mb-3">
<label>Sudah Dibayar</label>

<input
type="number"
step="1"
name="paid_amount"
class="form-control"
value="<?= $sale['paid_amount'] ?>"
required>
</div>

<div class="mb-3">

<label>Sisa Hutang</label>

<input
type="text"
class="form-control"
value="<?= money($sale['outstanding_amount']) ?>"
readonly>

</div>

<button
type="submit"
class="btn btn-success">

Simpan

</button>

<a
href="receivables.php"
class="btn btn-secondary">

Kembali

</a>

</form>

</div>

</div>

<?php page_footer(); ?>