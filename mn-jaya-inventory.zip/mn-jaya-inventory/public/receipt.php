<?php
require_once dirname(__DIR__) . '/includes/auth.php';
require_login();
$pdo = db();
$stmt = $pdo->prepare('SELECT s.*, c.name AS customer_name, c.phone FROM sales s LEFT JOIN customers c ON c.id=s.customer_id WHERE s.id=?');
$stmt->execute([(int)$_GET['id']]);
$sale = $stmt->fetch();
if (!$sale) {
    http_response_code(404);
    exit('Invoice tidak ditemukan.');
}
$itemsStmt = $pdo->prepare('SELECT si.*, p.name, p.sku FROM sale_items si JOIN products p ON p.id=si.product_id WHERE si.sale_id=?');
$itemsStmt->execute([$sale['id']]);
$items = $itemsStmt->fetchAll();
$width = setting('receipt_width', '80') === '58' ? 'receipt-58' : 'receipt-80';
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <title><?= e($sale['invoice_no']) ?></title>
    <link href="assets/css/app.css" rel="stylesheet">
</head>
<body class="receipt-page">
<main class="receipt <?= e($width) ?>">
    <h1><?= APP_NAME ?></h1>
    <p><?= e(setting('company_address', 'Gudang Lokal')) ?><br><?= e(setting('company_phone', '')) ?></p>
    <hr>
    <div class="receipt-row"><span>Faktur</span><strong><?= e($sale['invoice_no']) ?></strong></div>
    <div class="receipt-row"><span>Tanggal</span><span><?= e(date('d/m/Y H:i', strtotime($sale['sale_date']))) ?></span></div>
    <div class="receipt-row"><span>Pelanggan</span><span><?= e($sale['customer_name'] ?: 'Pelanggan Umum') ?></span></div>
    <hr>
    <?php foreach ($items as $item): ?>
        <div class="receipt-item">
            <strong><?= e($item['name']) ?></strong>
            <div class="receipt-row"><span><?= (float)$item['qty'] ?> <?= e($item['unit_name']) ?> x <?= money($item['selling_price']) ?></span><span><?= money($item['total']) ?></span></div>
        </div>
    <?php endforeach; ?>
    <hr>
    <div class="receipt-row"><span>Subtotal</span><span><?= money($sale['subtotal']) ?></span></div>
    <div class="receipt-row"><span>Diskon</span><span><?= money($sale['discount']) ?></span></div>
    <div class="receipt-row total"><span>Total</span><strong><?= money($sale['total']) ?></strong></div>
    <div class="receipt-row"><span>Dibayar</span><span><?= money($sale['paid_amount']) ?></span></div>
    <div class="receipt-row"><span>Piutang</span><span><?= money($sale['outstanding_amount']) ?></span></div>
    <?php if ($sale['due_date']): ?><div class="receipt-row"><span>Jatuh Tempo</span><span><?= e($sale['due_date']) ?></span></div><?php endif; ?>
    <hr>
    <p class="thanks">Terima kasih</p>
</main>
<div class="receipt-actions">
    <button onclick="window.print()">Cetak</button>
    <a href="pos.php">Kembali ke POS</a>
</div>
</body>
</html>
