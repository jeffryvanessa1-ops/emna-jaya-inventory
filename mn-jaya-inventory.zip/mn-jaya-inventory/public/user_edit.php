<?php

require_once dirname(__DIR__) . '/includes/layout.php';

require_role(['Admin']);

$id = (int)($_GET['id'] ?? 0);

$stmt = db()->prepare("
    SELECT *
    FROM users
    WHERE id = ?
");

$stmt->execute([$id]);

$userData = $stmt->fetch();

if (!$userData) {
    exit('User tidak ditemukan');
}

$roles = db()->query("
    SELECT *
    FROM roles
    ORDER BY name
")->fetchAll();

$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    try {

        $name = trim($_POST['name'] ?? '');
        $username = trim($_POST['username'] ?? '');
        $roleId = (int)($_POST['role_id'] ?? 0);
        $isActive = isset($_POST['is_active']) ? 1 : 0;

        if (
            $name === '' ||
            $username === '' ||
            $roleId <= 0
        ) {
            throw new Exception('Data belum lengkap.');
        }

        db()->prepare("
            UPDATE users
            SET
                role_id = ?,
                name = ?,
                username = ?,
                is_active = ?
            WHERE id = ?
        ")->execute([
            $roleId,
            $name,
            $username,
            $isActive,
            $id
        ]);

        if (!empty($_POST['password'])) {

            $hash = password_hash(
                $_POST['password'],
                PASSWORD_DEFAULT
            );

            db()->prepare("
                UPDATE users
                SET password_hash = ?
                WHERE id = ?
            ")->execute([
                $hash,
                $id
            ]);
        }

        flash(
            'success',
            'Data pengguna berhasil diperbarui.'
        );

        redirect('users.php');

    } catch (Throwable $e) {

        $error = $e->getMessage();

    }
}

page_header('Edit Pengguna');

?>

<div class="card">

<div class="card-header">
<h5>Edit Pengguna</h5>
</div>

<div class="card-body">

<?php if($error): ?>

<div class="alert alert-danger">
<?= e($error) ?>
</div>

<?php endif; ?>

<form method="post">

<div class="mb-3">

<label>Nama</label>

<input
type="text"
name="name"
class="form-control"
value="<?= e($userData['name']) ?>"
required>

</div>

<div class="mb-3">

<label>Username</label>

<input
type="text"
name="username"
class="form-control"
value="<?= e($userData['username']) ?>"
required>

</div>

<div class="mb-3">

<label>Password Baru</label>

<input
type="password"
name="password"
class="form-control">

<small>
Kosongkan jika tidak ingin mengubah password
</small>

</div>

<div class="mb-3">

<label>Role</label>

<select
name="role_id"
class="form-select"
required>

<?php foreach($roles as $role): ?>

<option
value="<?= $role['id'] ?>"
<?= $role['id'] == $userData['role_id'] ? 'selected' : '' ?>>

<?= e($role['name']) ?>

</option>

<?php endforeach; ?>

</select>

</div>

<div class="form-check mb-3">

<input
type="checkbox"
name="is_active"
class="form-check-input"

<?= $userData['is_active'] ? 'checked' : '' ?>>

<label class="form-check-label">
Aktif
</label>

</div>

<button
type="submit"
class="btn btn-primary">

Simpan

</button>

<a
href="users.php"
class="btn btn-secondary">

Kembali

</a>

</form>

</div>

</div>

<?php page_footer(); ?>
