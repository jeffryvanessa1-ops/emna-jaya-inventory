<?php
require_once dirname(__DIR__) . '/includes/layout.php';
require_login();
$pdo = db();


if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $items = json_decode($_POST['items_json'] ?? '[]', true) ?: [];
    if (!$items) {
        flash('danger', 'Cart is empty.');
        redirect('pos.php');
    }

    $pdo->beginTransaction();
    $invoice = next_invoice_no($pdo, 'sales', setting('invoice_prefix', 'INV'));
    $customerId = $_POST['customer_id'] ? (int)$_POST['customer_id'] : null;
    $pricingLevel = $_POST['pricing_level'] ?: 'retail';
    $subtotal = 0;
    $saleRows = [];

    foreach ($items as $item) {
        $stmt = $pdo->prepare('SELECT * FROM products WHERE id=? FOR UPDATE');
        $stmt->execute([(int)$item['product_id']]);
        $product = $stmt->fetch();
        if (!$product) {
            throw new RuntimeException('Produk tidak ditemukan.');
        }
        $unit = $item['unit_name'] ?: $product['base_unit'];
        $multiplier = product_unit_multiplier($product, $unit);
        $qty = (int)$item['qty'];
        $baseQty = $qty * $multiplier;
        if ((int)$product['stock_qty'] < $baseQty) {
            $pdo->rollBack();
            flash('danger', 'Stok tidak cukup untuk ' . $product['name'] . '.');
            redirect('pos.php');
        }
        $priceColumn = $pricingLevel . '_price';

$price = isset($item['price'])
    ? (float)$item['price']
    : (float)$product[$priceColumn];
        $lineDiscount = (int)($item['discount'] ?? 0);
        $lineTotal = max(0, ((int)$item['qty'] * $price) - $lineDiscount);
        $subtotal += $lineTotal;
        $saleRows[] = [
    $product,
    $unit,
    $multiplier,
    $qty, $baseQty, $price, $lineDiscount, $lineTotal];
    }

    $discount = (float)($_POST['discount'] ?? 0);
    $total = max(0, $subtotal - $discount);
    $paid = (float)($_POST['paid_amount'] ?? 0);
    $outstanding = max(0, $total - $paid);
    $status = $outstanding <= 0 ? 'paid' : ($paid > 0 ? 'partial' : 'credit');

$pdo->prepare(
    'INSERT INTO sales (
        customer_id,
        invoice_no,
        sale_date,
        pricing_level,
        payment_method,
        subtotal,
        discount,
        total,
        paid_amount,
        outstanding_amount,
        due_date,
        status,
        notes,
        created_by
    )
    VALUES (
        ?, ?, NOW(), ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?
    )'
)->execute([
    $customerId,
    $invoice,
    $pricingLevel,
    strtoupper($_POST['payment_method'] ?? 'CASH'),
    $subtotal,
    $discount,
    $total,
    $paid,
    $outstanding,
    $_POST['due_date'] ?: null,
    $status,
    trim($_POST['notes'] ?? ''),
    $_SESSION['user']['id']
]);

$saleId = (int)$pdo->lastInsertId();

    foreach ($saleRows as [$product, $unit, $multiplier, $qty, $baseQty, $price, $lineDiscount, $lineTotal]) {
        $pdo->prepare(
            'INSERT INTO sale_items (sale_id, product_id, unit_name, unit_multiplier, qty, base_qty, cost_price, selling_price, discount, total)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute([$saleId, $product['id'], $unit, $multiplier, $qty, $baseQty, $product['cost_price'], $price, $lineDiscount, $lineTotal]);
        add_stock_movement($pdo, (int)$product['id'], 'sale', -$baseQty, 'sale', $saleId, $invoice);
    }

    if ($paid > 0) {
        $pdo->prepare('INSERT INTO payments (sale_id, payment_date, method, amount, reference_no, notes, created_by) VALUES (?, NOW(), ?, ?, ?, ?, ?)')
            ->execute([$saleId, $_POST['payment_method'], $paid, trim($_POST['reference_no'] ?? ''), 'Pembayaran POS', $_SESSION['user']['id']]);
    }

    $pdo->commit();

/*
|--------------------------------------------------------------------------
| Redirect to Invoice
|--------------------------------------------------------------------------
*/

redirect('invoice.php?id=' . $saleId);

}

/*
|--------------------------------------------------------------------------
| Load POS Page
|--------------------------------------------------------------------------
*/

$customers = $pdo->query(
    'SELECT * FROM customers ORDER BY name'
)->fetchAll();

page_header('POS Kasir');
?>
<form method="post" id="posForm" class="pos-layout">
    <input type="hidden" name="items_json" id="posItemsJson">
    <section class="panel pos-left">
        <div class="panel-head"><h2>Cari / Pindai Produk</h2></div>
        <input class="form-control form-control-lg" id="productSearch" placeholder="Pindai barcode atau ketik SKU/nama produk" autocomplete="off">
        <div id="productResults" class="product-results"></div>
        <div class="table-responsive mt-3">
            <table class="table align-middle" id="cartTable" style="table-layout:fixed;width:100%;">

<thead>
<tr>
<th style="width:35%">Item</th>
<th style="width:12%">Satuan</th>
<th style="width:10%">Jumlah</th>
<th style="width:15%">Harga</th>
<th style="width:10%">Diskon</th>
<th style="width:15%">Total</th>
<th style="width:3%"></th>
</tr>

</thead>

            <tbody></tbody>
            </table>
        </div>
    </section>
    <aside class="panel pos-right">
        <div class="panel-head"><h2>Pembayaran</h2></div>
<label>Pelanggan</label>

<input
type="text"
id="customerSearch"
class="form-control mb-2"
placeholder="Cari pelanggan...">

<input
type="hidden"
name="customer_id"
id="customerId">

<div id="customerResults" class="product-results"></div>

<small class="text-muted d-block mt-2">
Pelanggan terpilih: <span id="customerSelectedText">Umum</span>
</small>

        <label>Level Harga<select class="form-select" name="pricing_level" id="pricingLevel">
            <option value="retail">Harga Eceran</option><option value="wholesale">Harga Grosir</option><option value="agent">Harga Agen</option>
        </select></label>
        <label>Diskon<input class="form-control" type="number" step="0.01" name="discount" id="saleDiscount" value="0"></label>
        <div class="col-md-3">

<label class="form-label">
Metode Pembayaran
</label>

<select
name="payment_method"
id="paymentMethod"
class="form-select">

<option value="CASH">
CASH
</option>

<option value="KREDIT">
KREDIT
</option>

</select>

</div>
        <label>Jumlah Dibayar<input class="form-control" type="number" step="0.01" name="paid_amount" id="paidAmount" value="0"></label>
        <label>Jatuh Tempo<input class="form-control" type="date" name="due_date"></label>
        <label>Referensi<input class="form-control" name="reference_no" placeholder="Ref transfer / QRIS"></label>
        <label>Catatan<textarea class="form-control" name="notes"></textarea></label>
        <div class="total-box">
            <span>Subtotal</span><strong id="posSubtotal">Rp 0</strong>
            <span>Total</span><strong id="posTotal">Rp 0</strong>
            <span>Sisa</span><strong id="posOutstanding">Rp 0</strong>
        </div>
        <button class="btn btn-dark btn-lg w-100 mt-3">Simpan & Cetak Invoice</button>
    </aside>
</form>

<?php
$customerData = array_map(function ($c) {
    return [
        'id' => (int)$c['id'],
        'name' => $c['name'],
        'level' => $c['price_level'] ?? 'retail',
    ];
}, $customers);
?>
<script>
window.__CUSTOMERS__ = <?= json_encode($customerData, JSON_UNESCAPED_UNICODE | JSON_UNESCAPED_SLASHES) ?>;
</script>

<?php page_footer(); ?>
