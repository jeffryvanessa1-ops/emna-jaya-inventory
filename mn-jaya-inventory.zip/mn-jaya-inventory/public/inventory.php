<?php
require_once dirname(__DIR__) . '/includes/layout.php';
require_role(['Admin', 'Manajer']);
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $productId = (int)$_POST['product_id'];
    $type = $_POST['movement_type'];
    $qty = (float)$_POST['qty'];
    $notes = trim($_POST['notes'] ?? '');
    if ($type === 'stock_out') {
        $qty = -abs($qty);
    } elseif ($type === 'adjustment') {
        $stmt = $pdo->prepare('SELECT stock_qty FROM products WHERE id=?');
        $stmt->execute([$productId]);
        $qty = (float)$_POST['new_stock'] - (float)$stmt->fetchColumn();
    }
    $pdo->beginTransaction();
    add_stock_movement($pdo, $productId, $type, $qty, 'manual', null, $notes);
    $pdo->commit();
    flash('success', 'Pergerakan stok disimpan.');
    redirect('inventory.php');
}

$products = $pdo->query('SELECT id, sku, name, base_unit, stock_qty FROM products WHERE is_active=1 ORDER BY name')->fetchAll();
$history = $pdo->query(
    'SELECT sm.*, p.sku, p.name, u.name AS user_name
     FROM stock_movements sm
     JOIN products p ON p.id = sm.product_id
     LEFT JOIN users u ON u.id = sm.created_by
     ORDER BY sm.created_at DESC LIMIT 100'
)->fetchAll();
page_header('Inventori');
?>
<div class="row g-4">
    <div class="col-lg-4">
        <div class="panel">
            <div class="panel-head"><h2>Pergerakan Stok</h2></div>
            <form method="post" class="stacked-form">
                <label>Produk<select class="form-select" name="product_id" required>
                    <?php foreach ($products as $p): ?><option value="<?= $p['id'] ?>"><?= e($p['sku'] . ' - ' . $p['name'] . ' (' . $p['stock_qty'] . ' ' . $p['base_unit'] . ')') ?></option><?php endforeach; ?>
                </select></label>
                <label>Movement Type<select class="form-select" name="movement_type" id="movementType">
                    <option value="stock_in">Stok Masuk</option>
                    <option value="stock_out">Stok Keluar</option>
                    <option value="adjustment">Penyesuaian Stok</option>
                </select></label>
                <label class="qty-field">Jumlah<input class="form-control" name="qty" type="number" step="0.01" value="1"></label>
                <label class="adjust-field d-none">Stok Baru<input class="form-control" name="new_stock" type="number" step="0.01" value="0"></label>
                <label>Catatan<textarea class="form-control" name="notes"></textarea></label>
                <button class="btn btn-dark">Simpan Pergerakan</button>
            </form>
        </div>
    </div>
    <div class="col-lg-8">
        <div class="panel">
            <div class="panel-head"><h2>Riwayat Stok</h2><a class="btn btn-sm btn-outline-dark" href="export.php?type=inventory">Excel</a></div>
            <div class="table-responsive">
                <table class="table align-middle">
                    <thead><tr><th>Tanggal</th><th>Produk</th><th>Jenis</th><th class="text-end">Jumlah</th><th class="text-end">Sebelum</th><th class="text-end">Sesudah</th><th>Pengguna</th></tr></thead>
                    <tbody>
                    <?php foreach ($history as $h): ?>
                        <tr>
                            <td><?= e(date('d M Y H:i', strtotime($h['created_at']))) ?></td>
                            <td><?= e($h['sku'] . ' - ' . $h['name']) ?></td>
                            <td><span class="badge text-bg-dark"><?= e(movement_type_label($h['movement_type'])) ?></span></td>
                            <td class="text-end"><?= (float)$h['qty'] ?></td>
                            <td class="text-end"><?= (float)$h['previous_stock'] ?></td>
                            <td class="text-end"><?= (float)$h['new_stock'] ?></td>
                            <td><?= e($h['user_name']) ?></td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>
<?php page_footer(); ?>
