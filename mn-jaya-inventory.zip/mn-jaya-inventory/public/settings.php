<?php

require_once dirname(__DIR__) . '/includes/layout.php';

require_role(['Admin']);

$message = '';
$error = '';

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    try {
        $pdo = db();

        if (isset($_POST['reset_transaksi'])) {
            $pdo->beginTransaction();

            $pdo->exec("DELETE FROM payments");
            $pdo->exec("DELETE FROM sale_items");
            $pdo->exec("DELETE FROM sales");
            $pdo->exec("DELETE FROM purchase_items");
            $pdo->exec("DELETE FROM purchases");
            $pdo->exec("DELETE FROM stock_movements");
            $pdo->exec("UPDATE products SET stock_qty = 0");

            $pdo->commit();

            $message = 'Semua transaksi berhasil direset.';
        } else {
            $stmt = $pdo->prepare("
                INSERT INTO settings (setting_key, setting_value)
                VALUES (?, ?)
                ON DUPLICATE KEY UPDATE setting_value = VALUES(setting_value)
            ");

            $fields = [
                'company_name' => $_POST['company_name'] ?? '',
                'company_address' => $_POST['company_address'] ?? '',
                'company_phone' => $_POST['company_phone'] ?? '',
                'company_email' => $_POST['company_email'] ?? '',
                'invoice_prefix' => $_POST['invoice_prefix'] ?? 'INV',
                'bank_account' => $_POST['bank_account'] ?? '',
                'invoice_mode' => $_POST['invoice_mode'] ?? 'invoice',
                'print_action' => $_POST['print_action'] ?? 'none',
                'invoice_footer_1' => $_POST['invoice_footer_1'] ?? '',
                'invoice_footer_2' => $_POST['invoice_footer_2'] ?? '',
                'invoice_footer_3' => $_POST['invoice_footer_3'] ?? '',
            ];

            foreach ($fields as $key => $value) {
                $stmt->execute([$key, trim((string)$value)]);
            }

            if (
                isset($_FILES['company_logo']) &&
                $_FILES['company_logo']['error'] === UPLOAD_ERR_OK
            ) {
                $allowed = ['png', 'jpg', 'jpeg', 'webp'];
                $ext = strtolower(pathinfo($_FILES['company_logo']['name'], PATHINFO_EXTENSION));

                if (!in_array($ext, $allowed, true)) {
                    throw new RuntimeException('Logo harus PNG, JPG, JPEG, atau WEBP.');
                }

                $uploadDir = dirname(__DIR__) . '/uploads';

                if (!is_dir($uploadDir)) {
                    mkdir($uploadDir, 0777, true);
                }

                $filename = 'company_logo_' . time() . '.' . $ext;

                if (!move_uploaded_file($_FILES['company_logo']['tmp_name'], $uploadDir . '/' . $filename)) {
                    throw new RuntimeException('Gagal mengupload logo.');
                }

                $stmt->execute(['company_logo', $filename]);
            }

            $message = 'Pengaturan berhasil disimpan.';
        }
    } catch (Throwable $e) {
        $error = $e->getMessage();
    }
}

page_header('Pengaturan Sistem');
?>

<div class="card">
    <div class="card-header">
        <h5>Pengaturan Perusahaan</h5>
    </div>

    <div class="card-body">

        <?php if ($message): ?>
            <div class="alert alert-success"><?= e($message) ?></div>
        <?php endif; ?>

        <?php if ($error): ?>
            <div class="alert alert-danger"><?= e($error) ?></div>
        <?php endif; ?>

        <form method="post" enctype="multipart/form-data">

            <div class="mb-3">
                <label class="form-label">Nama Perusahaan</label>
                <input
                    type="text"
                    name="company_name"
                    class="form-control"
                    value="<?= e(setting('company_name', APP_NAME)) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Logo Perusahaan</label>
                <input
                    type="file"
                    name="company_logo"
                    class="form-control"
                    accept="image/png,image/jpeg,image/jpg,image/webp">

                <?php if (setting('company_logo')): ?>
                    <div class="mt-2">
                        <?= company_logo_img(80) ?>
                    </div>
                <?php endif; ?>
            </div>

            <div class="mb-3">
                <label class="form-label">Alamat</label>
                <textarea
                    name="company_address"
                    class="form-control"
                    rows="3"><?= e(setting('company_address')) ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Telepon</label>
                <input
                    type="text"
                    name="company_phone"
                    class="form-control"
                    value="<?= e(setting('company_phone')) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Email</label>
                <input
                    type="email"
                    name="company_email"
                    class="form-control"
                    value="<?= e(setting('company_email')) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Prefix Invoice</label>
                <input
                    type="text"
                    name="invoice_prefix"
                    class="form-control"
                    value="<?= e(setting('invoice_prefix', 'INV')) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Rekening Bank</label>
                <textarea
                    name="bank_account"
                    class="form-control"
                    rows="3"><?= e(setting('bank_account')) ?></textarea>
            </div>

            <div class="mb-3">
                <label class="form-label">Footer Invoice 1</label>
                <input
                    type="text"
                    name="invoice_footer_1"
                    class="form-control"
                    value="<?= e(setting('invoice_footer_1')) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Footer Invoice 2</label>
                <input
                    type="text"
                    name="invoice_footer_2"
                    class="form-control"
                    value="<?= e(setting('invoice_footer_2')) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Footer Invoice 3</label>
                <input
                    type="text"
                    name="invoice_footer_3"
                    class="form-control"
                    value="<?= e(setting('invoice_footer_3')) ?>">
            </div>

            <div class="mb-3">
                <label class="form-label">Mode Invoice</label>
                <select name="invoice_mode" class="form-select">
                    <option value="receipt" <?= setting('invoice_mode') === 'receipt' ? 'selected' : '' ?>>
                        Thermal Receipt
                    </option>
                    <option value="invoice" <?= setting('invoice_mode') === 'invoice' ? 'selected' : '' ?>>
                        A4 Invoice
                    </option>
                </select>
            </div>

            <div class="mb-3">
                <label class="form-label">Aksi Setelah Simpan POS</label>
                <select name="print_action" class="form-select">
                    <option value="none" <?= setting('print_action') === 'none' ? 'selected' : '' ?>>
                        Tidak Ada
                    </option>
                    <option value="new_tab" <?= setting('print_action') === 'new_tab' ? 'selected' : '' ?>>
                        Buka Tab Baru
                    </option>
                    <option value="print" <?= setting('print_action') === 'print' ? 'selected' : '' ?>>
                        Langsung Print
                    </option>
                </select>
            </div>

            <div class="d-flex gap-2 flex-wrap">
                <button type="submit" class="btn btn-primary">Simpan Pengaturan</button>
                <button
                    type="submit"
                    name="reset_transaksi"
                    value="1"
                    class="btn btn-danger"
                    onclick="return confirm('PERINGATAN!\\n\\nSemua transaksi penjualan, pembelian, pembayaran dan stok akan dihapus.\\n\\nLanjutkan?')">
                    Reset Semua Transaksi
                </button>
            </div>

        </form>
    </div>
</div>

<?php page_footer(); ?>