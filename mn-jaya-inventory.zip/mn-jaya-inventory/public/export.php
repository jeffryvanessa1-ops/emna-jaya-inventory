<?php
require_once dirname(__DIR__) . '/includes/auth.php';
require_role(['Admin', 'Manajer']);
$pdo = db();
$type = $_GET['type'] ?? 'sales';
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');

header('Content-Type: application/vnd.ms-excel');
header('Content-Disposition: attachment; filename="' . $type . '-' . date('Ymd-His') . '.xls"');

function table_out(array $headers, array $rows): void
{
    echo '<table border="1"><thead><tr>';
    foreach ($headers as $h) {
        echo '<th>' . e($h) . '</th>';
    }
    echo '</tr></thead><tbody>';
    foreach ($rows as $row) {
        echo '<tr>';
        foreach ($row as $cell) {
            echo '<td>' . e((string)$cell) . '</td>';
        }
        echo '</tr>';
    }
    echo '</tbody></table>';
}

echo '<h2>' . APP_NAME . ' - Ekspor ' . e(ucfirst($type)) . '</h2>';
if ($type === 'inventory') {
    table_out(['SKU','Produk','Stok','Stok Minimum','Satuan','Modal','Eceran'], $pdo->query('SELECT sku, name, stock_qty, min_stock, base_unit, cost_price, retail_price FROM products WHERE is_active=1 ORDER BY name')->fetchAll(PDO::FETCH_NUM));
} elseif ($type === 'debts') {
    table_out(['Pelanggan','Telepon','Limit Kredit','Piutang'], $pdo->query("SELECT c.name, c.phone, c.credit_limit, COALESCE(SUM(s.outstanding_amount),0) AS debt FROM customers c LEFT JOIN sales s ON s.customer_id=c.id AND s.status <> 'void' GROUP BY c.id HAVING debt > 0")->fetchAll(PDO::FETCH_NUM));
} elseif ($type === 'low_stock') {
    table_out(['SKU','Produk','Stok','Stok Minimum','Satuan'], $pdo->query('SELECT sku, name, stock_qty, min_stock, base_unit FROM products WHERE is_active=1 AND stock_qty <= min_stock ORDER BY stock_qty ASC')->fetchAll(PDO::FETCH_NUM));
} elseif ($type === 'purchases') {
    $stmt = $pdo->prepare('SELECT p.invoice_no, p.purchase_date, s.name, p.status, p.total FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id WHERE p.purchase_date BETWEEN ? AND ? ORDER BY p.purchase_date DESC');
    $stmt->execute([$from, $to]);
    $rows = array_map(fn($r) => [$r[0], $r[1], $r[2], purchase_status_label($r[3]), $r[4]], $stmt->fetchAll(PDO::FETCH_NUM));
    table_out(['Faktur','Tanggal','Pemasok','Status','Total'], $rows);
} else {
    $stmt = $pdo->prepare('SELECT invoice_no, sale_date, pricing_level, subtotal, discount, total, paid_amount, outstanding_amount, status FROM sales WHERE DATE(sale_date) BETWEEN ? AND ? ORDER BY sale_date DESC');
    $stmt->execute([$from, $to]);
    $rows = array_map(fn($r) => [$r[0], $r[1], price_level_label($r[2]), $r[3], $r[4], $r[5], $r[6], $r[7], sale_status_label($r[8])], $stmt->fetchAll(PDO::FETCH_NUM));
    table_out(['Faktur','Tanggal','Level Harga','Subtotal','Diskon','Total','Dibayar','Piutang','Status'], $rows);
}
