<?php

require_once dirname(__DIR__) . '/includes/layout.php';

require_login();

$pdo = db();

/*
|--------------------------------------------------------------------------
| Simpan Pembayaran Cicilan
|--------------------------------------------------------------------------
*/

if (
    $_SERVER['REQUEST_METHOD'] === 'POST'
    && isset($_POST['save_payment'])
) {

    $saleId = (int)($_POST['sale_id'] ?? 0);
    $amount = (float)($_POST['amount'] ?? 0);

    if ($saleId > 0 && $amount > 0) {

        $stmt = $pdo->prepare("
            SELECT *
            FROM sales
            WHERE id = ?
        ");

        $stmt->execute([$saleId]);

        $sale = $stmt->fetch();

        if ($sale) {

            $paid =
                (float)$sale['paid_amount']
                + $amount;

            $outstanding =
                max(
                    0,
                    (float)$sale['outstanding_amount']
                    - $amount
                );

            $status =
                $outstanding <= 0
                    ? 'paid'
                    : 'credit';

            $pdo->prepare("
                UPDATE sales
                SET
                    paid_amount = ?,
                    outstanding_amount = ?,
                    status = ?,
                    updated_at = NOW()
                WHERE id = ?
            ")->execute([
                $paid,
                $outstanding,
                $status,
                $saleId
            ]);
            log_activity(
    'Pembayaran piutang transaksi #' .
    $saleId .
    ' sebesar Rp ' .
    number_format($amount, 0, ',', '.')
);

            flash(
                'success',
                'Pembayaran berhasil disimpan'
            );

            redirect('receivables.php');
        }
    }
}

/*
|--------------------------------------------------------------------------
| Ambil Data Piutang
|--------------------------------------------------------------------------
*/

$sql = "
SELECT
    c.id,
    c.name,
    c.phone,
    MIN(s.id) AS sale_id,
    SUM(s.total) AS total_hutang,
    SUM(s.total - s.outstanding_amount) AS sudah_bayar,
    SUM(s.outstanding_amount) AS sisa_hutang,
    MAX(s.updated_at) AS terakhir_diubah
FROM customers c
INNER JOIN sales s
    ON s.customer_id = c.id
WHERE s.outstanding_amount > 0
GROUP BY c.id, c.name
ORDER BY c.name
";

$rows = $pdo->query($sql)->fetchAll();

page_header('Buku Piutang');

?>

<div class="card">

```
<div class="card-header">
    <h5 class="mb-0">Daftar Piutang Pelanggan</h5>
</div>

<div class="card-body">

    <table class="table table-bordered table-hover align-middle">

        <thead>

            <tr>
                <th>Pelanggan</th>
                <th>No HP</th>
                <th>Total Hutang</th>
                <th>Sudah Bayar</th>
                <th>Sisa Hutang</th>
                <th>Perubahan</th>
                <th width="180">Bayar Cicilan</th>
                <th width="180">Aksi</th>
                <th width="100">WA</th>
            </tr>

        </thead>

        <tbody>

        <?php foreach ($rows as $row): ?>

            <tr>

                <form method="post">

                    <td>
                        <?= e($row['name']) ?>
                    </td>

                    <td><?= e($row['phone']) ?></td>

                    <td>
                        <?= money($row['total_hutang']) ?>
                    </td>

                    <td>
                        <?= money($row['sudah_bayar']) ?>
                    </td>

                    <td>
                        <strong class="text-danger">
                            <?= money($row['sisa_hutang']) ?>
                        </strong>
                    </td>

                    <td>
                        <?= date(
                            'd/m/Y H:i',
                            strtotime($row['terakhir_diubah'])
                        ) ?>
                    </td>

                    <td>

                        <input
                            type="hidden"
                            name="sale_id"
                            value="<?= $row['sale_id'] ?>">

                        <input
                            type="number"
                            name="amount"
                            min="1"
                            class="form-control form-control-sm"
                            placeholder="Nominal">
                        
                            

                    </td>

                    <td class="text-nowrap">

                        <button
                            type="submit"
                            name="save_payment"
                            class="btn btn-success btn-sm">

                            Bayar

                        </button>

                        <a
                            href="edit_receivable.php?id=<?= $row['sale_id'] ?>"
                            class="btn btn-warning btn-sm">

                            Edit

                        </a>

                        <a
                            href="delete_receivable.php?id=<?= $row['sale_id'] ?>"
                            class="btn btn-danger btn-sm"
                            onclick="return confirm('Yakin ingin menghapus piutang ini?')">

                            Hapus

                        </a>

                    </td>
                    <td>

<?php

$phone = preg_replace('/[^0-9]/', '', $row['phone']);

if (substr($phone, 0, 1) === '0') {
    $phone = '62' . substr($phone, 1);
}

$message =
"Halo " . $row['name'] .
"\n\nKami dari MN JAYA." .
"\n\nSisa piutang Anda saat ini sebesar:" .
"\n" . money($row['sisa_hutang']) .
"\n\nMohon melakukan pembayaran apabila sudah jatuh tempo." .
"\n\nTerima kasih.";

?>

<a
href="https://wa.me/<?= e($phone) ?>?text=<?= urlencode($message) ?>"
target="_blank"
class="btn btn-success btn-sm">

<i class="bi bi-whatsapp"></i>
WA

</a>

</td>
                </form>

            </tr>

        <?php endforeach; ?>

        </tbody>

    </table>

</div>
```

</div>

<?php page_footer(); ?>
