<?php
require_once dirname(__DIR__) . '/includes/layout.php';
require_role(['Admin', 'Manajer']);
$pdo = db();
$from = $_GET['from'] ?? date('Y-m-01');
$to = $_GET['to'] ?? date('Y-m-d');

$daily = $pdo->prepare("SELECT DATE(sale_date) AS day, COUNT(*) AS trx, SUM(total) AS total FROM sales WHERE DATE(sale_date) BETWEEN ? AND ? AND status <> 'void' GROUP BY DATE(sale_date) ORDER BY day DESC");
$daily->execute([$from, $to]);
$monthly = $pdo->query("SELECT DATE_FORMAT(sale_date,'%Y-%m') AS month, COUNT(*) AS trx, SUM(total) AS total FROM sales WHERE status <> 'void' GROUP BY DATE_FORMAT(sale_date,'%Y-%m') ORDER BY month DESC LIMIT 12")->fetchAll();
$inventory = $pdo->query('SELECT sku, name, stock_qty, min_stock, base_unit, cost_price, retail_price FROM products WHERE is_active=1 ORDER BY name')->fetchAll();
$lowStock = $pdo->query('SELECT sku, name, stock_qty, min_stock, base_unit FROM products WHERE is_active=1 AND stock_qty <= min_stock ORDER BY stock_qty ASC')->fetchAll();
$profit = $pdo->prepare("SELECT SUM(si.total) AS sales_total, SUM(si.base_qty * si.cost_price) AS cost_total, SUM(si.total - (si.base_qty * si.cost_price)) AS profit FROM sale_items si JOIN sales s ON s.id=si.sale_id WHERE DATE(s.sale_date) BETWEEN ? AND ? AND s.status <> 'void'");
$profit->execute([$from, $to]);
$profitRow = $profit->fetch();
$debts = $pdo->query("SELECT c.name, c.phone, c.credit_limit, COALESCE(SUM(s.outstanding_amount),0) AS debt FROM customers c LEFT JOIN sales s ON s.customer_id=c.id AND s.status <> 'void' GROUP BY c.id HAVING debt > 0 ORDER BY debt DESC")->fetchAll();
$purchases = $pdo->prepare("SELECT p.invoice_no, p.purchase_date, s.name AS supplier_name, p.status, p.total FROM purchases p LEFT JOIN suppliers s ON s.id=p.supplier_id WHERE p.purchase_date BETWEEN ? AND ? ORDER BY p.purchase_date DESC");
$purchases->execute([$from, $to]);
page_header('Laporan');
?>
<form class="panel report-filter mb-4" method="get">
    <label>From<input class="form-control" type="date" name="from" value="<?= e($from) ?>"></label>
    <label>To<input class="form-control" type="date" name="to" value="<?= e($to) ?>"></label>
    <button class="btn btn-dark">Apply</button>
    <a class="btn btn-outline-dark" href="export.php?type=sales&from=<?= e($from) ?>&to=<?= e($to) ?>">Excel Penjualan</a>
    <a class="btn btn-outline-dark" href="export.php?type=debts">Excel Piutang</a>
    <a class="btn btn-outline-dark" href="export.php?type=low_stock">Excel Stok Rendah</a>
    <button type="button" class="btn btn-outline-dark" onclick="window.print()">Cetak / PDF</button>
</form>

<section class="metric-grid mb-4">
    <div class="metric"><span>Penjualan</span><strong><?= money($profitRow['sales_total'] ?? 0) ?></strong></div>
    <div class="metric"><span>Modal</span><strong><?= money($profitRow['cost_total'] ?? 0) ?></strong></div>
    <div class="metric"><span>Laba</span><strong><?= money($profitRow['profit'] ?? 0) ?></strong></div>
</section>

<a
    href="invoice.php?id=<?= $sale['id'] ?>"
    target="_blank"
    class="btn btn-primary btn-sm"
>
    Invoice
</a>

<div class="row g-4">
    <div class="col-xl-6"><div class="panel"><div class="panel-head"><h2>Laporan Penjualan Harian</h2></div>
        <table class="table"><thead><tr><th>Tanggal</th><th class="text-end">Transaksi</th><th class="text-end">Total</th></tr></thead><tbody>
        <?php foreach ($daily->fetchAll() as $r): ?><tr><td><?= e($r['day']) ?></td><td class="text-end"><?= (int)$r['trx'] ?></td><td class="text-end"><?= money($r['total']) ?></td></tr><?php endforeach; ?>
        </tbody></table></div></div>
    <div class="col-xl-6"><div class="panel"><div class="panel-head"><h2>Laporan Penjualan Bulanan</h2></div>
        <table class="table"><thead><tr><th>Bulan</th><th class="text-end">Transaksi</th><th class="text-end">Total</th></tr></thead><tbody>
        <?php foreach ($monthly as $r): ?><tr><td><?= e($r['month']) ?></td><td class="text-end"><?= (int)$r['trx'] ?></td><td class="text-end"><?= money($r['total']) ?></td></tr><?php endforeach; ?>
        </tbody></table></div></div>
    <div class="col-xl-6"><div class="panel"><div class="panel-head"><h2>Laporan Inventori</h2><a class="btn btn-sm btn-outline-dark" href="export.php?type=inventory">Excel</a></div>
        <table class="table"><thead><tr><th>SKU</th><th>Produk</th><th class="text-end">Stok</th></tr></thead><tbody>
        <?php foreach ($inventory as $r): ?><tr class="<?= $r['stock_qty'] <= $r['min_stock'] ? 'table-warning' : '' ?>"><td><?= e($r['sku']) ?></td><td><?= e($r['name']) ?></td><td class="text-end"><?= (float)$r['stock_qty'] ?> <?= e($r['base_unit']) ?></td></tr><?php endforeach; ?>
        </tbody></table></div></div>
    <div class="col-xl-6"><div class="panel"><div class="panel-head"><h2>Laporan Stok Rendah</h2></div>
        <table class="table"><thead><tr><th>SKU</th><th>Produk</th><th class="text-end">Stok</th><th class="text-end">Minimum</th></tr></thead><tbody>
        <?php foreach ($lowStock as $r): ?><tr><td><?= e($r['sku']) ?></td><td><?= e($r['name']) ?></td><td class="text-end"><?= (float)$r['stock_qty'] ?> <?= e($r['base_unit']) ?></td><td class="text-end"><?= (float)$r['min_stock'] ?> <?= e($r['base_unit']) ?></td></tr><?php endforeach; ?>
        <?php if (!$lowStock): ?><tr><td colspan="4" class="text-muted">Tidak ada produk stok rendah.</td></tr><?php endif; ?>
        </tbody></table></div></div>
    <div class="col-xl-6"><div class="panel"><div class="panel-head"><h2>Laporan Piutang Pelanggan</h2><a class="btn btn-sm btn-dark" href="payments.php">Pembayaran</a></div>
        <table class="table"><thead><tr><th>Pelanggan</th><th>Telepon</th><th class="text-end">Piutang</th></tr></thead><tbody>
        <?php foreach ($debts as $r): ?><tr><td><?= e($r['name']) ?></td><td><?= e($r['phone']) ?></td><td class="text-end"><?= money($r['debt']) ?></td></tr><?php endforeach; ?>
        </tbody></table></div></div>
    <div class="col-12"><div class="panel"><div class="panel-head"><h2>Laporan Pembelian</h2><a class="btn btn-sm btn-outline-dark" href="export.php?type=purchases&from=<?= e($from) ?>&to=<?= e($to) ?>">Excel</a></div>
        <table class="table"><thead><tr><th>Faktur</th><th>Tanggal</th><th>Pemasok</th><th>Status</th><th class="text-end">Total</th></tr></thead><tbody>
        <?php foreach ($purchases->fetchAll() as $r): ?><tr><td><?= e($r['invoice_no']) ?></td><td><?= e($r['purchase_date']) ?></td><td><?= e($r['supplier_name']) ?></td><td><?= e(purchase_status_label($r['status'])) ?></td><td class="text-end"><?= money($r['total']) ?></td></tr><?php endforeach; ?>
        </tbody></table></div></div>
</div>
<?php page_footer(); ?>
