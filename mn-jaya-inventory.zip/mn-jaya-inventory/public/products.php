<?php

require_once dirname(__DIR__) . '/includes/layout.php';
require_role(['Admin', 'Manajer']);

$pdo = db();
$categories = $pdo->query('SELECT * FROM categories ORDER BY name')->fetchAll();
$edit = null;

if (isset($_GET['delete'])) {
    $pdo->prepare('UPDATE products SET is_active = 0 WHERE id = ?')->execute([(int)$_GET['delete']]);
    flash('success', 'Produk dihapus.');
    redirect('products.php');
}

if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM products WHERE id = ?');
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $id = (int)($_POST['id'] ?? 0);
    $imageName = $_POST['existing_image'] ?? null;
    if (!empty($_FILES['image']['name'])) {
        if (!is_dir(UPLOAD_DIR)) {
            mkdir(UPLOAD_DIR, 0775, true);
        }
        $ext = strtolower(pathinfo($_FILES['image']['name'], PATHINFO_EXTENSION));
        $imageName = uniqid('product_', true) . '.' . $ext;
        move_uploaded_file($_FILES['image']['tmp_name'], UPLOAD_DIR . '/' . $imageName);
    }

    $data = [
        $_POST['category_id'] ?: null, trim($_POST['sku']), trim($_POST['barcode']) ?: null, trim($_POST['name']),
        $imageName, trim($_POST['base_unit'] ?: 'PCS'), trim($_POST['unit_1_name']) ?: null, (int)($_POST['unit_1_qty'] ?: 1),
        trim($_POST['unit_2_name']) ?: null, (int)($_POST['unit_2_qty'] ?: 1), (float)$_POST['cost_price'],
        (float)$_POST['retail_price'], (float)$_POST['wholesale_price'], (float)$_POST['agent_price'],
        (float)$_POST['stock_qty'], (float)$_POST['min_stock']
    ];

    if ($id > 0) {
        $pdo->prepare(
            'UPDATE products SET category_id=?, sku=?, barcode=?, name=?, image=?, base_unit=?, unit_1_name=?, unit_1_qty=?, unit_2_name=?, unit_2_qty=?, cost_price=?, retail_price=?, wholesale_price=?, agent_price=?, stock_qty=?, min_stock=? WHERE id=?'
        )->execute([...$data, $id]);
        flash('success', 'Produk diperbarui.');
    } else {
        $pdo->prepare(
            'INSERT INTO products (category_id, sku, barcode, name, image, base_unit, unit_1_name, unit_1_qty, unit_2_name, unit_2_qty, cost_price, retail_price, wholesale_price, agent_price, stock_qty, min_stock)
             VALUES (?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?, ?)'
        )->execute($data);
        flash('success', 'Produk ditambahkan.');
    }
    redirect('products.php');
}

$products = $pdo->query(
    'SELECT products.*, categories.name AS category_name
     FROM products LEFT JOIN categories ON categories.id = products.category_id
     WHERE products.is_active = 1 ORDER BY products.name'
)->fetchAll();

page_header('Produk');
?>
<div class="row g-4">
    <div class="col-xl-4">
        <div class="panel">
            <div class="panel-head"><h2><?= $edit ? 'Ubah Produk' : 'Tambah Produk' ?></h2></div>
            <form method="post" enctype="multipart/form-data" class="stacked-form">
                <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
                <input type="hidden" name="existing_image" value="<?= e($edit['image'] ?? '') ?>">
                <label>Nama Produk<input class="form-control" name="name" required value="<?= e($edit['name'] ?? '') ?>"></label>
                <div class="row g-2">
                    <label class="col">SKU<input class="form-control" name="sku" required value="<?= e($edit['sku'] ?? '') ?>"></label>
                    <label class="col">Barcode<input class="form-control" name="barcode" value="<?= e($edit['barcode'] ?? '') ?>"></label>
                </div>
                <label>Kategori
                    <select class="form-select" name="category_id">
                        <option value="">Tanpa Kategori</option>
                        <?php foreach ($categories as $cat): ?>
                            <option value="<?= $cat['id'] ?>" <?= selected((string)($edit['category_id'] ?? ''), (string)$cat['id']) ?>><?= e($cat['name']) ?></option>
                        <?php endforeach; ?>
                    </select>
                </label>
                <div class="row g-2">
                    <label class="col">Satuan Dasar<input class="form-control" name="base_unit" value="<?= e($edit['base_unit'] ?? 'PCS') ?>"></label>
                    <label class="col">Gambar<input class="form-control" type="file" name="image" accept="image/*"></label>
                </div>
                <div class="row g-2">
                    <label class="col">Satuan 1<input class="form-control" name="unit_1_name" placeholder="Dus" value="<?= e($edit['unit_1_name'] ?? '') ?>"></label>
                    <label class="col">Jumlah<input class="form-control" name="unit_1_qty" type="number" min="1" value="<?= e($edit['unit_1_qty'] ?? 1) ?>"></label>
                </div>
                <div class="row g-2">
                    <label class="col">Satuan 2<input class="form-control" name="unit_2_name" placeholder="Karton" value="<?= e($edit['unit_2_name'] ?? '') ?>"></label>
                    <label class="col">Jumlah<input class="form-control" name="unit_2_qty" type="number" min="1" value="<?= e($edit['unit_2_qty'] ?? 1) ?>"></label>
                </div>
                <div class="row g-2">
                    <label class="col">Harga Modal<input class="form-control" name="cost_price" type="number" step="0.01" value="<?= e($edit['cost_price'] ?? 0) ?>"></label>
                    <label class="col">Eceran<input class="form-control" name="retail_price" type="number" step="0.01" value="<?= e($edit['retail_price'] ?? 0) ?>"></label>
                </div>
                <div class="row g-2">
                    <label class="col">Grosir<input class="form-control" name="wholesale_price" type="number" step="0.01" value="<?= e($edit['wholesale_price'] ?? 0) ?>"></label>
                    <label class="col">Agen<input class="form-control" name="agent_price" type="number" step="0.01" value="<?= e($edit['agent_price'] ?? 0) ?>"></label>
                </div>
                <div class="row g-2">
                    <label class="col">Stok<input class="form-control" name="stock_qty" type="number" step="0.01" value="<?= e($edit['stock_qty'] ?? 0) ?>"></label>
                    <label class="col">Minimum<input class="form-control" name="min_stock" type="number" step="0.01" value="<?= e($edit['min_stock'] ?? 0) ?>"></label>
                </div>
                <button class="btn btn-dark w-100"><?= $edit ? 'Perbarui Produk' : 'Simpan Produk' ?></button>
            </form>
        </div>
    </div>
    <div class="col-xl-8">
        <div class="panel">
            <div class="panel-head"><h2>Daftar Produk</h2><input class="form-control table-search" data-table="productsTable" placeholder="Cari produk"></div>
            <div class="table-responsive">
                <table class="table align-middle" id="productsTable">
                    <thead><tr><th>Gambar</th><th>SKU</th><th>Nama</th><th>Kategori</th><th>Harga</th><th>Stok</th><th></th></tr></thead>
                    <tbody>
                    <?php foreach ($products as $p): ?>
                        <tr class="<?= $p['stock_qty'] <= $p['min_stock'] ? 'table-warning' : '' ?>">
                            <td><?php if ($p['image']): ?><img class="thumb" src="uploads/products/<?= e($p['image']) ?>" alt=""><?php endif; ?></td>
                            <td><?= e($p['sku']) ?><br><small><?= e($p['barcode']) ?></small></td>
                            <td><?= e($p['name']) ?></td>
                            <td><?= e($p['category_name']) ?></td>
                            <td><small>R <?= money($p['retail_price']) ?><br>W <?= money($p['wholesale_price']) ?><br>A <?= money($p['agent_price']) ?></small></td>
                            <td><?= (float)$p['stock_qty'] ?> <?= e($p['base_unit']) ?><br><small>Min <?= (float)$p['min_stock'] ?></small></td>
                            <td class="text-end">
                                <a class="btn btn-sm btn-outline-dark" href="?edit=<?= $p['id'] ?>">Ubah</a>
                                <a class="btn btn-sm btn-outline-danger" href="?delete=<?= $p['id'] ?>" data-confirm="Hapus produk ini?">Hapus</a>
                            </td>
                        </tr>
                    <?php endforeach; ?>
                    </tbody>
                </table>
            </div>
        </div>
    </div>
</div>

<?php page_footer(); ?>
