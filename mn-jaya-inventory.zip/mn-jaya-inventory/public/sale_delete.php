<?php

require_once dirname(__DIR__) . '/includes/auth.php';

require_role(['Admin']);

$pdo = db();

$id = (int)($_GET['id'] ?? 0);

if ($id <= 0) {
    header('Location: sales.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Cek transaksi
|--------------------------------------------------------------------------
*/

$stmt = $pdo->prepare("
    SELECT *
    FROM sales
    WHERE id = ?
");

$stmt->execute([$id]);

$sale = $stmt->fetch();

if (!$sale) {

    flash('danger', 'Transaksi tidak ditemukan');

    header('Location: sales.php');
    exit;
}

/*
|--------------------------------------------------------------------------
| Jangan void dua kali
|--------------------------------------------------------------------------
*/

if (($sale['status'] ?? '') === 'void') {

    flash('warning', 'Transaksi sudah dibatalkan');

    header('Location: sales.php');
    exit;
}

$pdo->beginTransaction();

try {

    /*
    |--------------------------------------------------------------------------
    | Ambil item transaksi
    |--------------------------------------------------------------------------
    */

    $stmt = $pdo->prepare("
        SELECT
            product_id,
            qty
        FROM sale_items
        WHERE sale_id = ?
    ");

    $stmt->execute([$id]);

    $items = $stmt->fetchAll();

    /*
    |--------------------------------------------------------------------------
    | Kembalikan stok
    |--------------------------------------------------------------------------
    */

    foreach ($items as $item) {

        add_stock_movement(
            $pdo,
            (int)$item['product_id'],
            'adjustment',
            (float)$item['qty'],
            'sale_void',
            $id,
            'VOID transaksi penjualan'
        );

    }

    /*
    |--------------------------------------------------------------------------
    | VOID transaksi
    |--------------------------------------------------------------------------
    */

    $pdo->prepare("
        UPDATE sales
        SET
            status = 'void',
            updated_at = NOW()
        WHERE id = ?
    ")->execute([$id]);

    $pdo->commit();
    log_activity(
    'VOID transaksi ID #' . $id
);

    flash(
        'success',
        'Transaksi berhasil dibatalkan dan stok dikembalikan'
    );

} catch (Throwable $e) {

    $pdo->rollBack();

    flash(
        'danger',
        'Gagal membatalkan transaksi: ' . $e->getMessage()
    );

}

header('Location: sales.php');
exit;
