<?php

require_once dirname(__DIR__) . '/includes/layout.php';

require_role(['Admin']);

$logs = db()->query("
SELECT
    l.*,
    u.name AS user_name
FROM activity_logs l
LEFT JOIN users u
    ON u.id = l.user_id
ORDER BY l.id DESC
")->fetchAll();

page_header('Audit Log');
?>

<div class="card">

<div class="card-header">
<h5>Audit Log</h5>
</div>

<div class="card-body">

<table class="table table-bordered">

<thead>
<tr>
<th>Waktu</th>
<th>User</th>
<th>Aktivitas</th>
</tr>
</thead>

<tbody>

<?php foreach($logs as $log): ?>

<tr>

<td>
<?= date('d/m/Y H:i:s', strtotime($log['created_at'])) ?>
</td>

<td>
<?= e($log['user_name'] ?? '-') ?>
</td>

<td>
<?= e($log['activity']) ?>
</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>

<?php page_footer(); ?>