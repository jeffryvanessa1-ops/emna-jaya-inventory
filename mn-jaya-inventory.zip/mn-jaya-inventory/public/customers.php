<?php
require_once dirname(__DIR__) . '/includes/layout.php';
require_login();
$pdo = db();
$edit = null;
if (isset($_GET['delete']) && has_role(['Admin', 'Manajer'])) {
    $pdo->prepare('DELETE FROM customers WHERE id=?')->execute([(int)$_GET['delete']]);
    flash('success', 'Pelanggan dihapus.');
    redirect('customers.php');
}
if (isset($_GET['edit'])) {
    $stmt = $pdo->prepare('SELECT * FROM customers WHERE id=?');
    $stmt->execute([(int)$_GET['edit']]);
    $edit = $stmt->fetch();
}
if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $data = [trim($_POST['name']), trim($_POST['phone']), trim($_POST['address']), $_POST['price_level'], (float)$_POST['credit_limit']];
    if (!empty($_POST['id'])) {
        $pdo->prepare('UPDATE customers SET name=?, phone=?, address=?, price_level=?, credit_limit=? WHERE id=?')->execute([...$data, (int)$_POST['id']]);
    } else {
        $pdo->prepare('INSERT INTO customers (name, phone, address, price_level, credit_limit) VALUES (?, ?, ?, ?, ?)')->execute($data);
    }
    flash('success', 'Pelanggan disimpan.');
    redirect('customers.php');
}
$rows = $pdo->query("SELECT c.*, COALESCE(SUM(s.outstanding_amount),0) AS debt FROM customers c LEFT JOIN sales s ON s.customer_id=c.id AND s.status <> 'void' GROUP BY c.id ORDER BY c.name")->fetchAll();
page_header('Pelanggan');
?>
<div class="row g-4">
    <div class="col-lg-4"><div class="panel"><div class="panel-head"><h2><?= $edit ? 'Ubah Pelanggan' : 'Tambah Pelanggan' ?></h2></div>
        <form method="post" class="stacked-form">
            <input type="hidden" name="id" value="<?= e($edit['id'] ?? '') ?>">
            <label>Nama<input class="form-control" name="name" required value="<?= e($edit['name'] ?? '') ?>"></label>
            <label>Telepon<input class="form-control" name="phone" value="<?= e($edit['phone'] ?? '') ?>"></label>
            <label>Alamat<textarea class="form-control" name="address"><?= e($edit['address'] ?? '') ?></textarea></label>
            <label>Level Harga<select class="form-select" name="price_level">
                <?php foreach (['retail'=>'Harga Eceran','wholesale'=>'Harga Grosir','agent'=>'Harga Agen'] as $k=>$v): ?><option value="<?= $k ?>" <?= selected($edit['price_level'] ?? 'retail', $k) ?>><?= $v ?></option><?php endforeach; ?>
            </select></label>
            <label>Limit Kredit<input class="form-control" name="credit_limit" type="number" step="0.01" value="<?= e($edit['credit_limit'] ?? 0) ?>"></label>
            <button class="btn btn-dark">Simpan Pelanggan</button>
        </form></div></div>
    <div class="col-lg-8"><div class="panel"><div class="panel-head"><h2>Database Pelanggan</h2></div>
        <table class="table align-middle"><thead><tr><th>Nama</th><th>Telepon</th><th>Level</th><th>Kredit</th><th>Piutang</th><th></th></tr></thead><tbody>
        <?php foreach ($rows as $r): ?><tr><td><?= e($r['name']) ?></td><td><?= e($r['phone']) ?></td><td><?= e(price_level_label($r['price_level'])) ?></td><td><?= money($r['credit_limit']) ?></td><td><?= money($r['debt']) ?></td><td class="text-end"><a class="btn btn-sm btn-outline-dark" href="?edit=<?= $r['id'] ?>">Ubah</a><?php if (has_role(['Admin', 'Manajer'])): ?> <a class="btn btn-sm btn-outline-danger" href="?delete=<?= $r['id'] ?>" data-confirm="Hapus pelanggan?">Hapus</a><?php endif; ?></td></tr><?php endforeach; ?>
        </tbody></table></div></div>
</div>
<?php page_footer(); ?>
