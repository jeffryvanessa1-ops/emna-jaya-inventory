<?php
require_once dirname(__DIR__) . '/includes/layout.php';
require_login();
$pdo = db();

if ($_SERVER['REQUEST_METHOD'] === 'POST') {
    $saleId = (int)$_POST['sale_id'];
    $amount = (float)$_POST['amount'];
    $pdo->beginTransaction();
    $stmt = $pdo->prepare('SELECT outstanding_amount, paid_amount FROM sales WHERE id=? FOR UPDATE');
    $stmt->execute([$saleId]);
    $sale = $stmt->fetch();
    if ($sale && $amount > 0) {
        $amount = min($amount, (float)$sale['outstanding_amount']);
        $newOutstanding = (float)$sale['outstanding_amount'] - $amount;
        $newPaid = (float)$sale['paid_amount'] + $amount;
        $status = $newOutstanding <= 0 ? 'paid' : 'partial';
        $pdo->prepare('UPDATE sales SET paid_amount=?, outstanding_amount=?, status=? WHERE id=?')->execute([$newPaid, $newOutstanding, $status, $saleId]);
        $pdo->prepare('INSERT INTO payments (sale_id, payment_date, method, amount, reference_no, notes, created_by) VALUES (?, NOW(), ?, ?, ?, ?, ?)')
            ->execute([$saleId, $_POST['method'], $amount, trim($_POST['reference_no'] ?? ''), trim($_POST['notes'] ?? ''), $_SESSION['user']['id']]);
        flash('success', 'Pembayaran dicatat.');
    }
    $pdo->commit();
    redirect('payments.php');
}

$debts = $pdo->query("SELECT s.*, c.name AS customer_name FROM sales s LEFT JOIN customers c ON c.id=s.customer_id WHERE s.outstanding_amount > 0 AND s.status <> 'void' ORDER BY s.due_date IS NULL, s.due_date, s.sale_date")->fetchAll();
$history = $pdo->query("SELECT p.*, s.invoice_no, c.name AS customer_name FROM payments p LEFT JOIN sales s ON s.id=p.sale_id LEFT JOIN customers c ON c.id=s.customer_id ORDER BY p.payment_date DESC LIMIT 100")->fetchAll();
page_header('Pembayaran Pelanggan');
?>
<div class="row g-4">
    <div class="col-lg-5">
        <div class="panel"><div class="panel-head"><h2>Catat Pembayaran Piutang</h2></div>
            <form method="post" class="stacked-form">
                <label>Faktur<select class="form-select" name="sale_id"><?php foreach ($debts as $d): ?><option value="<?= $d['id'] ?>"><?= e($d['invoice_no'] . ' - ' . ($d['customer_name'] ?: 'Pelanggan Umum') . ' - ' . money($d['outstanding_amount'])) ?></option><?php endforeach; ?></select></label>
                <label>Metode<select class="form-select" name="method"><option value="cash">Tunai</option><option value="transfer">Transfer</option><option value="qris">QRIS</option></select></label>
                <label>Jumlah<input class="form-control" name="amount" type="number" step="0.01" required></label>
                <label>Referensi<input class="form-control" name="reference_no"></label>
                <label>Catatan<textarea class="form-control" name="notes"></textarea></label>
                <button class="btn btn-dark">Simpan Pembayaran</button>
            </form>
        </div>
    </div>
    <div class="col-lg-7">
        <div class="panel"><div class="panel-head"><h2>Riwayat Pembayaran</h2></div>
            <table class="table align-middle"><thead><tr><th>Tanggal</th><th>Faktur</th><th>Pelanggan</th><th>Metode</th><th class="text-end">Jumlah</th></tr></thead><tbody>
            <?php foreach ($history as $h): ?><tr><td><?= e(date('d M Y H:i', strtotime($h['payment_date']))) ?></td><td><?= e($h['invoice_no']) ?></td><td><?= e($h['customer_name']) ?></td><td><?= e(payment_method_label($h['method'])) ?></td><td class="text-end"><?= money($h['amount']) ?></td></tr><?php endforeach; ?>
            </tbody></table>
        </div>
    </div>
</div>
<?php page_footer(); ?>
