<?php

require_once dirname(__DIR__) . '/includes/layout.php';

require_login();

$pdo = db();

$id = (int)($_GET['id'] ?? 0);

$stmt = $pdo->prepare("
SELECT *
FROM sales
WHERE id=?
");

$stmt->execute([$id]);

$sale = $stmt->fetch();

if (!$sale) {
    exit('Data tidak ditemukan');
}

if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    $amount = (float)($_POST['amount'] ?? 0);

    if ($amount > 0) {

        $pdo->beginTransaction();

        $pdo->prepare("
        INSERT INTO receivable_payments
        (
            sale_id,
            amount,
            notes,
            created_by
        )
        VALUES
        (
            ?,?,?,?
        )
        ")->execute([
            $sale['id'],
            $amount,
            trim($_POST['notes'] ?? ''),
            $_SESSION['user']['id']
        ]);

        $newPaid =
            $sale['paid_amount'] + $amount;

        $newOutstanding =
            max(
                0,
                $sale['outstanding_amount'] - $amount
            );

        $newStatus =
            $newOutstanding <= 0
                ? 'paid'
                : 'credit';

        $pdo->prepare("
        UPDATE sales
        SET
            paid_amount=?,
            outstanding_amount=?,
            status=?
        WHERE id=?
        ")->execute([
            $newPaid,
            $newOutstanding,
            $newStatus,
            $sale['id']
        ]);

        $pdo->commit();

        flash(
            'success',
            'Pembayaran berhasil disimpan'
        );

        redirect(
            'receivable_detail.php?id=' .
            $sale['customer_id']
        );
    }
}

page_header('Bayar Piutang');
?>

<div class="card">

<div class="card-header">
<h5>Bayar Piutang</h5>
</div>

<div class="card-body">

<table class="table">

<tr>
<td>Invoice</td>
<td><?= e($sale['invoice_no']) ?></td>
</tr>

<tr>
<td>Total</td>
<td><?= money($sale['total']) ?></td>
</tr>

<tr>
<td>Terbayar</td>
<td><?= money($sale['paid_amount']) ?></td>
</tr>

<tr>
<td>Sisa Hutang</td>
<td>
<strong class="text-danger">
<?= money($sale['outstanding_amount']) ?>
</strong>
</td>
</tr>

</table>

<form method="post">

<div class="mb-3">
<label>Jumlah Bayar</label>
<input
type="number"
step="1"
min="1"
max="<?= (int)$sale['outstanding_amount'] ?>"
name="amount"
class="form-control"
required>
</div>

<div class="mb-3">
<label>Keterangan</label>
<textarea
name="notes"
class="form-control"></textarea>
</div>

<button
type="submit"
class="btn btn-success">

Simpan Pembayaran

</button>

<a
href="receivable_detail.php?id=<?= $sale['customer_id'] ?>"
class="btn btn-secondary">

Kembali

</a>

</form>

</div>

</div>

<?php page_footer(); ?>
