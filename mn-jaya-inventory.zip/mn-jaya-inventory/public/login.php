<?php
require_once dirname(__DIR__) . '/includes/auth.php';

if (current_user()) {
    redirect('dashboard.php');
}

$error = '';
if ($_SERVER['REQUEST_METHOD'] === 'POST') {

    if (login_user(
        trim($_POST['username'] ?? ''),
        $_POST['password'] ?? ''
    )) {

        redirect('dashboard.php');
    }

    $error = 'Nama pengguna atau kata sandi salah.';

}
?>
<!doctype html>
<html lang="en">
<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Masuk - MN. JAYA</title>
    <link href="assets/vendor/bootstrap.min.css" rel="stylesheet">
    <link href="assets/css/app.css" rel="stylesheet">
</head>
<body class="login-page">
<main class="login-card">
    <div class="login-brand">
        <span>MN</span>
        <div>
            <h1>MN. JAYA</h1>
            <p>Inventori Gudang Grosir & POS</p>
        </div>
    </div>
    <?php if ($error): ?><div class="alert alert-danger"><?= e($error) ?></div><?php endif; ?>
    <form method="post" autocomplete="off">
        <label class="form-label">Nama Pengguna</label>
        <input class="form-control form-control-lg" name="username" required autofocus>
        <label class="form-label mt-3">Kata Sandi</label>
        <input class="form-control form-control-lg" name="password" type="password" required>
        <button class="btn btn-dark btn-lg w-100 mt-4">Masuk</button>
    </form>
    <p class="demo-note">Contoh: admin / password</p>
</main>
</body>
</html>
