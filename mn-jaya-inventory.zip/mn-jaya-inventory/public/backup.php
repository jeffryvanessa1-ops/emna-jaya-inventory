<?php

require_once dirname(__DIR__) . '/includes/auth.php';

require_role(['Admin']);

$dbHost = DB_HOST;
$dbName = DB_NAME;
$dbUser = DB_USER;
$dbPass = DB_PASS;

$filename =
    'backup_' .
    date('Ymd_His') .
    '.sql';

header('Content-Type: application/octet-stream');
header('Content-Disposition: attachment; filename="' . $filename . '"');

$command =
    'mysqldump ' .
    '--host=' . escapeshellarg($dbHost) . ' ' .
    '--user=' . escapeshellarg($dbUser) . ' ' .
    '--password=' . escapeshellarg($dbPass) . ' ' .
    escapeshellarg($dbName);

passthru($command);

exit;
