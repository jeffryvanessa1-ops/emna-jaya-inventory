<?php
require_once dirname(__DIR__, 2) . '/includes/auth.php';
require_login();
header('Content-Type: application/json');

$q = '%' . trim($_GET['q'] ?? '') . '%';
$stmt = db()->prepare(
    'SELECT id, sku, barcode, name, base_unit, unit_1_name, unit_1_qty, unit_2_name, unit_2_qty, cost_price,
            retail_price, wholesale_price, agent_price, stock_qty
     FROM products
     WHERE is_active=1 AND (name LIKE ? OR sku LIKE ? OR barcode LIKE ?)
     ORDER BY name LIMIT 50'
);
$stmt->execute([$q, $q, $q]);
echo json_encode($stmt->fetchAll());
