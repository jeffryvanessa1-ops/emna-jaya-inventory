<?php

require_once dirname(__DIR__) . '/includes/layout.php';

require_login();

$pageTitle = 'Daftar Transaksi';

$stmt = db()->query("
    SELECT
        s.*,
        c.name customer_name
    FROM sales s
    LEFT JOIN customers c
        ON c.id = s.customer_id
    ORDER BY s.id DESC
");

$sales = $stmt->fetchAll();

page_header($pageTitle);

?>

<div class="card">

<div class="card-header d-flex justify-content-between">

<h5 class="mb-0">
Daftar Transaksi
</h5>

<input
type="text"
class="form-control table-search"
data-table="salesTable"
placeholder="Cari Invoice / Pelanggan..."
style="width:300px;">

</div>

<div class="card-body p-0">

<table class="table table-striped table-hover mb-0" id="salesTable">

<thead>

<tr>
<th>No Invoice</th>
<th>Tanggal</th>
<th>Pelanggan</th>
<th>Total</th>
<th>Dibayar</th>
<th>Piutang</th>
<th>Status</th>
<th width="180">Aksi</th>
</tr>

</thead>

<tbody>

<?php foreach($sales as $sale): ?>

<tr>

<td>
<?= e($sale['invoice_no']) ?>
</td>

<td>
<?= date('d/m/Y', strtotime($sale['sale_date'])) ?>
</td>

<td>
<?= e($sale['customer_name'] ?: 'UMUM') ?>
</td>

<td class="text-end">
<?= money($sale['total']) ?>
</td>

<td class="text-end">
<?= money($sale['paid_amount']) ?>
</td>

<td class="text-end">
<?= money($sale['outstanding_amount']) ?>
</td>

<td>

<?php if(($sale['status'] ?? '') === 'void'): ?>

<span class="badge bg-danger">
BATAL
</span>

<?php elseif($sale['outstanding_amount'] <= 0): ?>

<span class="badge bg-success">
LUNAS
</span>

<?php else: ?>

<span class="badge bg-warning text-dark">
PIUTANG
</span>

<?php endif; ?>

</td>

<td>

<?php if(($sale['status'] ?? '') !== 'void'): ?>

<a
href="invoice.php?id=<?= $sale['id'] ?>"
class="btn btn-sm btn-primary">
Invoice
</a>

<a
href="invoice.php?id=<?= $sale['id'] ?>&autoprint=1"
target="_blank"
class="btn btn-sm btn-secondary">
Print
</a>

<?php endif; ?>

<?php if(($sale['status'] ?? '') !== 'void'): ?>

<a
href="sale_delete.php?id=<?= $sale['id'] ?>"
class="btn btn-sm btn-danger"
onclick="return confirm('Batalkan transaksi ini? Stok akan dikembalikan.')">

Void

</a>

<?php endif; ?>
</td>

</tr>

<?php endforeach; ?>

</tbody>

</table>

</div>

</div>

<?php page_footer(); ?>
