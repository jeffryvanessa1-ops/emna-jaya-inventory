const rupiah = n => 'Rp ' + Number(n || 0).toLocaleString('id-ID', { maximumFractionDigits: 0 });

const escapeHtml = value =>
    String(value ?? '').replace(/[&<>"']/g, ch => ({
        '&': '&amp;',
        '<': '&lt;',
        '>': '&gt;',
        '"': '&quot;',
        "'": '&#39;'
    }[ch]));

document.addEventListener('click', e => {
    const confirmEl = e.target.closest('[data-confirm]');
    if (confirmEl && !confirm(confirmEl.dataset.confirm)) e.preventDefault();
    if (e.target.closest('#sidebarToggle')) document.querySelector('.sidebar')?.classList.toggle('open');
});

document.querySelectorAll('.table-search').forEach(input => {
    input.addEventListener('input', () => {
        const table = document.getElementById(input.dataset.table);
        const q = input.value.toLowerCase();
        table?.querySelectorAll('tbody tr').forEach(row => {
            row.style.display = row.textContent.toLowerCase().includes(q) ? '' : 'none';
        });
    });
});

const movementType = document.getElementById('movementType');
if (movementType) {
    const sync = () => {
        document.querySelector('.adjust-field')?.classList.toggle('d-none', movementType.value !== 'adjustment');
        document.querySelector('.qty-field')?.classList.toggle('d-none', movementType.value === 'adjustment');
    };
    movementType.addEventListener('change', sync);
    sync();
}

const purchaseForm = document.getElementById('purchaseForm');
if (purchaseForm) {
    let purchaseItems = [];
    const productSelect = document.getElementById('purchaseProduct');
    const unitSelect = document.getElementById('purchaseUnit');
    const costInput = document.getElementById('purchaseCost');

    const syncUnits = () => {
        const opt = productSelect.selectedOptions[0];
        unitSelect.innerHTML = '';
        [opt.dataset.base, opt.dataset.u1, opt.dataset.u2]
            .filter(Boolean)
            .forEach(u => unitSelect.add(new Option(u, u)));
        costInput.value = opt.dataset.cost || 0;
    };

    const renderPurchase = () => {
        const tbody = document.querySelector('#purchaseItemsTable tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        let total = 0;

        purchaseItems.forEach((item, i) => {
            const line = Number(item.qty || 0) * Number(item.cost_price || 0);
            total += line;
            tbody.insertAdjacentHTML('beforeend', `
<tr>
    <td>${escapeHtml(item.name)}</td>
    <td>${escapeHtml(item.unit_name)}</td>
    <td class="text-end">${parseInt(item.qty || 0, 10)}</td>
    <td class="text-end">${rupiah(item.cost_price)}</td>
    <td class="text-end">${rupiah(line)}</td>
    <td class="text-end">
        <button class="btn btn-sm btn-outline-danger" type="button" data-purchase-remove="${i}">Hapus</button>
    </td>
</tr>`);
        });

        const purchaseTotal = document.getElementById('purchaseTotal');
        if (purchaseTotal) purchaseTotal.textContent = rupiah(total);

        const purchaseItemsJson = document.getElementById('purchaseItemsJson');
        if (purchaseItemsJson) purchaseItemsJson.value = JSON.stringify(purchaseItems);
    };

    productSelect?.addEventListener('change', syncUnits);
    syncUnits();

    document.getElementById('addPurchaseItem')?.addEventListener('click', () => {
        const opt = productSelect.selectedOptions[0];
        purchaseItems.push({
            product_id: productSelect.value,
            name: opt.dataset.name,
            unit_name: unitSelect.value,
            qty: Number(document.getElementById('purchaseQty').value || 1),
            cost_price: Number(costInput.value || 0)
        });
        renderPurchase();
    });

    document.addEventListener('click', e => {
        if (e.target.dataset.purchaseRemove !== undefined) {
            purchaseItems.splice(Number(e.target.dataset.purchaseRemove), 1);
            renderPurchase();
        }
    });

    purchaseForm.addEventListener('submit', renderPurchase);
}

const posForm = document.getElementById('posForm');
if (posForm) {
    let cart = [];
    let latestProducts = [];

    const customers = Array.isArray(window.__CUSTOMERS__) ? window.__CUSTOMERS__ : [];

    const search = document.getElementById('productSearch');
    const results = document.getElementById('productResults');
    const level = document.getElementById('pricingLevel');
    const paymentMethod = document.getElementById('paymentMethod');
    const paidAmount = document.getElementById('paidAmount');

    const customerSearch = document.getElementById('customerSearch');
    const customerResults = document.getElementById('customerResults');
    const customerId = document.getElementById('customerId');
    const customerSelectedText = document.getElementById('customerSelectedText');

    const priceFor = p => Number(p?.[`${level.value}_price`] || 0);
    const unitOptions = p => [p.base_unit, p.unit_1_name, p.unit_2_name].filter(Boolean);

    const syncPaidState = total => {
        if (!paymentMethod || !paidAmount) return;

        if (paymentMethod.value === 'KREDIT') {
            paidAmount.value = 0;
            paidAmount.readOnly = true;
            paidAmount.dataset.manual = '1';
        } else {
            paidAmount.readOnly = false;
            if (!paidAmount.dataset.manual) {
                paidAmount.value = Math.round(total);
            }
        }
    };

    const renderCart = () => {
        const tbody = document.querySelector('#cartTable tbody');
        if (!tbody) return;

        tbody.innerHTML = '';
        let subtotal = 0;

        cart.forEach((item, i) => {
            if (!item.manual_price) {
                item.price = Number(item[`${level.value}_price`] || item.price || 0);
            }

            const qty = Math.max(1, parseInt(item.qty || 1, 10) || 1);
            item.qty = qty;

            const discount = Number(item.discount || 0);
            const line = Math.max(0, (qty * Number(item.price || 0)) - discount);
            subtotal += line;

            tbody.insertAdjacentHTML('beforeend', `
<tr>
    <td>${escapeHtml(item.name)}<br><small>${escapeHtml(item.sku || '')}</small></td>
    <td>
        <select class="form-select form-select-sm cart-unit" data-i="${i}">
            ${item.units.map(u => `<option ${u === item.unit_name ? 'selected' : ''}>${escapeHtml(u)}</option>`).join('')}
        </select>
    </td>
    <td>
        <input class="form-control form-control-sm cart-qty text-end" data-i="${i}" type="number" min="1" step="1" value="${qty}">
    </td>
    <td>
        <input class="form-control form-control-sm cart-price text-end" data-i="${i}" type="number" step="1" value="${Number(item.price || 0)}">
    </td>
    <td>
        <input class="form-control form-control-sm cart-disc text-end" data-i="${i}" type="number" step="1" value="${discount}">
    </td>
    <td class="text-end">${rupiah(line)}</td>
    <td class="text-end">
        <button class="btn btn-sm btn-outline-danger" type="button" data-cart-remove="${i}">Hapus</button>
    </td>
</tr>`);
        });

        const discount = Number(document.getElementById('saleDiscount')?.value || 0);
        const total = Math.max(0, subtotal - discount);

        syncPaidState(total);

        const paid = Number(paidAmount?.value || 0);

        const posSubtotal = document.getElementById('posSubtotal');
        const posTotal = document.getElementById('posTotal');
        const posOutstanding = document.getElementById('posOutstanding');
        const posItemsJson = document.getElementById('posItemsJson');

        if (posSubtotal) posSubtotal.textContent = rupiah(subtotal);
        if (posTotal) posTotal.textContent = rupiah(total);
        if (posOutstanding) posOutstanding.textContent = rupiah(Math.max(0, total - paid));
        if (posItemsJson) posItemsJson.value = JSON.stringify(cart);
    };

    const addToCart = p => {
        const existing = cart.find(i => i.product_id == p.id && i.unit_name === p.base_unit);

        if (existing) {
            existing.qty += 1;
        } else {
            cart.push({
                product_id: p.id,
                sku: p.sku,
                name: p.name,
                unit_name: p.base_unit,
                units: unitOptions(p),
                qty: 1,
                price: priceFor(p),
                retail_price: p.retail_price,
                wholesale_price: p.wholesale_price,
                agent_price: p.agent_price,
                discount: 0,
                manual_price: false
            });
        }

        renderCart();
        if (search) search.value = '';
        if (results) results.innerHTML = '';
        search?.focus();
    };

    const doSearch = async () => {
        const q = search?.value.trim() || '';
        if (!q) {
            if (results) results.innerHTML = '';
            return;
        }

        latestProducts = await fetch(`api/products.php?q=${encodeURIComponent(q)}`).then(r => r.json());
        const exact = latestProducts.find(p => p.barcode === q || p.sku === q);

        if (exact && q.length >= 5) {
            addToCart(exact);
            return;
        }

        if (results) {
            results.innerHTML = latestProducts.map(p => `
<button type="button" class="product-hit" data-product="${p.id}">
    <span>
        <strong>${escapeHtml(p.name)}</strong><br>
        <small>${escapeHtml(p.sku)} | Stok ${escapeHtml(p.stock_qty)} ${escapeHtml(p.base_unit)}</small>
    </span>
    <span>${rupiah(priceFor(p))}</span>
</button>`).join('');
        }
    };

    const renderCustomers = (query = '') => {
        if (!customerResults) return;

        const q = query.trim().toLowerCase();
        const filtered = customers.filter(c => (c.name || '').toLowerCase().includes(q)).slice(0, 30);

        customerResults.innerHTML = filtered.length
            ? filtered.map(c => `
<button type="button" class="product-hit" data-customer="${c.id}" data-level="${escapeHtml(c.level || 'retail')}">
    <span>
        <strong>${escapeHtml(c.name)}</strong><br>
        <small>Level: ${escapeHtml(c.level || 'retail')}</small>
    </span>
    <span>Pilih</span>
</button>`).join('')
            : `<div class="text-muted small">Tidak ada pelanggan.</div>`;
    };

    const chooseCustomer = customer => {
        if (!customerId || !customerSelectedText) return;

        customerId.value = customer.id;
        customerSelectedText.textContent = customer.name;

        if (level) {
            level.value = customer.level || 'retail';
            level.dispatchEvent(new Event('change'));
        }

        renderCart();
    };

    search?.addEventListener('input', () => {
        clearTimeout(search._t);
        search._t = setTimeout(doSearch, 180);
    });

    document.addEventListener('click', e => {
        const hit = e.target.closest('[data-product]');
        if (hit) {
            addToCart(latestProducts.find(p => String(p.id) === String(hit.dataset.product)));
            return;
        }

        const customerHit = e.target.closest('[data-customer]');
        if (customerHit) {
            const customer = customers.find(c => String(c.id) === String(customerHit.dataset.customer));
            if (customer) {
                chooseCustomer(customer);
                if (customerSearch) customerSearch.value = customer.name;
                renderCustomers(customer.name);
            }
            return;
        }

        if (e.target.dataset.cartRemove !== undefined) {
            cart.splice(Number(e.target.dataset.cartRemove), 1);
            renderCart();
        }
    });

    document.addEventListener('change', e => {
        const i = e.target.dataset.i;
        if (i === undefined) return;

        if (e.target.classList.contains('cart-qty')) {
            cart[i].qty = Math.max(1, parseInt(e.target.value || 1, 10) || 1);
            renderCart();
            return;
        }

        if (e.target.classList.contains('cart-price')) {
            cart[i].price = Number(e.target.value || 0);
            cart[i].manual_price = true;
            renderCart();
            return;
        }

        if (e.target.classList.contains('cart-unit')) {
            cart[i].unit_name = e.target.value;
            renderCart();
        }
    });

    document.addEventListener('input', e => {
        const i = e.target.dataset.i;
        if (i === undefined) return;

        if (e.target.classList.contains('cart-disc')) {
            cart[i].discount = Number(e.target.value || 0);
            renderCart();
        }
    });

    if (customerSearch && customerResults) {
        renderCustomers('');

        customerSearch.addEventListener('input', () => {
            renderCustomers(customerSearch.value);
        });

        customerSearch.addEventListener('keydown', e => {
            if (e.key === 'Enter') {
                e.preventDefault();
                const first = customerResults.querySelector('[data-customer]');
                if (first) first.click();
            }
        });
    }

    if (paymentMethod && paidAmount) {
        paymentMethod.addEventListener('change', () => {
            if (paymentMethod.value === 'KREDIT') {
                paidAmount.value = 0;
                paidAmount.readOnly = true;
                paidAmount.dataset.manual = '1';
            } else {
                paidAmount.readOnly = false;
                paidAmount.dataset.manual = '';
            }
            renderCart();
        });

        paidAmount.addEventListener('input', () => {
            paidAmount.dataset.manual = '1';
            renderCart();
        });
    }

    if (level) {
        level.addEventListener('change', renderCart);
    }

    ['saleDiscount'].forEach(id => {
        document.getElementById(id)?.addEventListener('input', renderCart);
    });

    posForm.addEventListener('submit', renderCart);

    renderCart();
}

/*
|--------------------------------------------------------------------------
| Sidebar Folder Toggle
|--------------------------------------------------------------------------
*/

document.addEventListener('DOMContentLoaded', () => {

    document.querySelectorAll('.menu-title').forEach(title => {

        title.addEventListener('click', () => {

            const group = title.closest('.menu-group');

            if (group) {
                group.classList.toggle('collapsed');
            }

        });

    });

});