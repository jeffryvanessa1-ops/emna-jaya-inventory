<?php
require_once dirname(__DIR__) . '/includes/auth.php';

require_login();

$pdo = db();

$stmt = $pdo->prepare("
    SELECT
        s.*,
        c.name AS customer_name,
        c.address,
        c.phone
    FROM sales s
    LEFT JOIN customers c
        ON c.id = s.customer_id
    WHERE s.id = ?
");

$stmt->execute([(int)($_GET['id'] ?? 0)]);

$sale = $stmt->fetch();

if (!$sale) {
    http_response_code(404);
    exit('Invoice tidak ditemukan.');
}

$rawPaymentMethod = trim((string)($sale['payment_method'] ?? ''));
if ($rawPaymentMethod === '') {
    $paymentMethod = ((float)($sale['outstanding_amount'] ?? 0) > 0) ? 'KREDIT' : 'CASH';
} else {
    $upper = strtoupper($rawPaymentMethod);
    if (in_array($upper, ['CASH', 'TUNAI'], true)) {
        $paymentMethod = 'CASH';
    } elseif (in_array($upper, ['KREDIT', 'CREDIT'], true)) {
        $paymentMethod = 'KREDIT';
    } else {
        $paymentMethod = $upper;
    }
}

$itemsStmt = $pdo->prepare("
    SELECT
        si.*,
        p.name,
        p.sku
    FROM sale_items si
    JOIN products p
        ON p.id = si.product_id
    WHERE si.sale_id = ?
");

$itemsStmt->execute([$sale['id']]);
$items = $itemsStmt->fetchAll();
?>
<!doctype html>
<html lang="id">
<head>
<meta charset="utf-8">
<title>Invoice <?= e($sale['invoice_no']) ?></title>

<style>
body{
    font-family: Arial, sans-serif;
    margin: 8px;
    color: #000;
    font-size: 12px;
}

.invoice{
    width: 95%;
    margin: auto;
    font-size: 12px;
}

.header{
    margin-bottom: 4px;
}

table{
    width: 100%;
    border-collapse: collapse;
}

th{
    background: #666 !important;
    color: #fff !important;
    -webkit-print-color-adjust: exact;
    print-color-adjust: exact;
}

th, td{
    border: 1px solid #ccc;
    padding: 4px 6px;
}

.company-title{
    font-size: 28px;
    font-weight: 700;
    line-height: 1;
    margin: 0 0 6px 0;
}

.invoice-title{
    font-size: 26px;
    font-weight: 700;
    text-align: right;
    line-height: 1;
    margin: 0 0 10px 0;
}

.company-info{
    line-height: 1.45;
    margin: 0;
}

.invoice-meta{
    width: 100%;
    border-collapse: collapse;
    table-layout: fixed;
}

.invoice-meta td{
    border: none;
    padding: 2px 0;
    vertical-align: top;
}

.invoice-meta .label{
    width: 110px;
    white-space: nowrap;
}

.invoice-meta .colon{
    width: 12px;
    text-align: center;
}

.invoice-meta .value{
    text-align: left;
    white-space: nowrap;
    font-weight: 700;
}

.customer-box{
    width: 100%;
    margin-bottom: 10px;
}

.customer-box td{
    border: none;
    padding: 0;
    vertical-align: top;
}

.customer-card{
    border: 1px solid #ddd;
    background: #fff;
    padding: 10px;
}

.customer-name{
    font-size: 18px;
    font-weight: 700;
    text-transform: uppercase;
    margin: 2px 0 6px 0;
}

.customer-total-label{
    font-size: 12px;
    color: #232323;
    text-transform: uppercase;
    margin-bottom: 4px;
    text-align: right;
}

.customer-total-value{
    font-size: 37px;
    font-weight: 700;
    text-align: right;
    white-space: nowrap;
}

.total-box{
    width: 350px;
    margin-left: auto;
    margin-top: 10px;
}

.total-box td{
    border: 1px solid #ccc;
    padding: 4px 6px;
}

.footer-sign{
    width: 100%;
    margin-top: 12px;
}

.footer-sign td{
    border: none !important;
    vertical-align: top;
}

.footer-left{
    width: 70%;
    font-size: 12px;
    line-height: 1.7;
    padding-right: 20px;
}

.footer-right{
    width: 30%;
}

.signature-table{
    width: 100%;
    border: none;
}

.signature-table td{
    border: none !important;
    text-align: center;
    width: 50%;
    vertical-align: top;
}

.no-print{
    margin-top: 15px;
}

@media print{
    .no-print{
        display:none;
    }

    .invoice{
        width:100%;
        margin:0;
    }

    @page{
        size:A4;
        margin:1cm;
    }
}
</style>
</head>

<?php if (isset($_GET['autoprint'])): ?>
<script>
window.onload = function () {
    window.print();
};
</script>
<?php endif; ?>

<body>
<div class="invoice">

    <div class="header">
        <table style="width:100%; border:none; border-collapse:collapse;">
            <tr>
                <td style="width:65%; border:none; vertical-align:top;">
                    <table style="border:none; border-collapse:collapse;">
                        <tr>
                            <td style="border:none; width:110px; vertical-align:top;">
                                <?php if (setting('company_logo')): ?>
                                    <img
                                        src="../uploads/<?= e(setting('company_logo')) ?>"
                                        alt="Logo"
                                        style="height:90px;width:auto;display:block;">
                                <?php endif; ?>
                            </td>
                            <td style="border:none; vertical-align:top; padding-left:10px;">
                                <div class="company-title">
                                    <?= e(setting('company_name', 'MN JAYA')) ?>
                                </div>

                                <div class="company-info">
                                    Alamat : <?= e(setting('company_address', '')) ?><br>
                                    Telepon : <?= e(setting('company_phone', '')) ?><br>
                                    Kasir : <?= e(current_user()['name'] ?? '-') ?>
                                </div>
                            </td>
                        </tr>
                    </table>
                </td>

                <td style="width:35%; border:none; vertical-align:top;">
                    <div class="invoice-title">INVOICE</div>

                    <table class="invoice-meta">
                        <tr>
                            <td class="label">No Invoice</td>
                            <td class="colon">:</td>
                            <td class="value"><?= e($sale['invoice_no']) ?></td>
                        </tr>
                        <tr>
                            <td class="label">Tanggal</td>
                            <td class="colon">:</td>
                            <td class="value"><?= date('d/m/Y', strtotime($sale['sale_date'])) ?> </td>
                        </tr>
                        <tr>
                            <td class="label">Pembayaran</td>
                            <td class="colon">:</td>
                            <td class="value"><strong><?= e($paymentMethod) ?></strong></td>
                        </tr>
                    </table>
                </td>
            </tr>
        </table>
    </div>

    <hr style="margin:4px 0;">

    <table class="customer-box">
        <tr>
            <td>
                <div class="customer-card">
                    <table style="width:100%; border:none; border-collapse:collapse;">
                        <tr>
                            <td style="width:70%; border:none; vertical-align:top;">
                                <div style="
                                    font-size:12px;
                                    color:#666;
                                    text-transform:uppercase;
                                    margin-bottom:4px;
                                ">
                                    KEPADA YTH.
                                </div>

                                <div class="customer-name">
                                    <?= e($sale['customer_name'] ?: 'UMUM') ?>
                                </div>

                                <?php if (!empty($sale['address'])): ?>
                                    <div style="font-size:14px; margin-bottom:4px;">
                                        <?= nl2br(e($sale['address'])) ?>
                                    </div>
                                <?php endif; ?>

                                <div style="font-size:14px;">
                                    <strong>Telp :</strong> <?= e($sale['phone'] ?: '-') ?>
                                </div>
                            </td>

                            <td style="width:30%; border:none; text-align:right; vertical-align:top;">
                                <div class="customer-total-label">
                                    TOTAL TAGIHAN
                                </div>

                                <div class="customer-total-value">
                                    <?= money($sale['total']) ?>
                                </div>
                            </td>
                        </tr>
                    </table>
                </div>
            </td>
        </tr>
    </table>

    <table>
        <thead>
            <tr>
                <th>Nama Produk</th>
                <th>Qty</th>
                <th>Satuan</th>
                <th>Harga</th>
                <th>Jumlah</th>
            </tr>
        </thead>
        <tbody>
            <?php foreach ($items as $item): ?>
                <tr>
                    <td><?= e($item['name']) ?></td>
                    <td align="center"><?= (int)$item['qty'] ?></td>
                    <td align="center"><?= e($item['unit_name']) ?></td>
                    <td align="right"><?= money($item['selling_price']) ?></td>
                    <td align="right"><?= money($item['total']) ?></td>
                </tr>
            <?php endforeach; ?>
        </tbody>
    </table>

    <div class="total-box">
        <table style="width:350px;margin-left:auto;">
            <tr>
                <td>Subtotal</td>
                <td align="right"><?= money($sale['subtotal']) ?></td>
            </tr>
            <tr>
                <td>Diskon</td>
                <td align="right"><?= money($sale['discount']) ?></td>
            </tr>
            <tr>
                <td><strong>Total</strong></td>
                <td align="right"><strong><?= money($sale['total']) ?></strong></td>
            </tr>
            <?php if ((float)$sale['outstanding_amount'] > 0): ?>
                <tr>
                    <td>Piutang</td>
                    <td align="right"><?= money($sale['outstanding_amount']) ?></td>
                </tr>
            <?php endif; ?>
        </table>
    </div>

    <table class="footer-sign">
        <tr>
            <td class="footer-left">
                <?php if (trim(setting('invoice_footer_1')) !== ''): ?>
                    <div><?= e(setting('invoice_footer_1')) ?></div>
                <?php endif; ?>

                <?php if (trim(setting('invoice_footer_2')) !== ''): ?>
                    <div><?= e(setting('invoice_footer_2')) ?></div>
                <?php endif; ?>

                <?php if (trim(setting('invoice_footer_3')) !== ''): ?>
                    <div><?= e(setting('invoice_footer_3')) ?></div>
                <?php endif; ?>
            </td>

            <td class="footer-right">
                <table class="signature-table">
                    <tr>
                        <td>
                            <strong>Hormat Kami</strong><br><br><br>
                            <strong>MN JAYA</strong>
                        </td>
                        <td>
                            <strong>Diterima Oleh</strong><br><br><br>
                            __________________
                        </td>
                    </tr>
                </table>
            </td>
        </tr>
    </table>

    <div class="no-print">
        <br>
        <button onclick="window.print()">Cetak Invoice</button>
        <a href="pos.php">Kembali ke POS</a>
    </div>

</div>
</body>
</html>