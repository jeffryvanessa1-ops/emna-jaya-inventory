<?php
require_once dirname(__DIR__) . '/includes/auth.php';

require_login();

$pdo = db();

$stmt = $pdo->prepare("
    SELECT
        s.*,
        c.name AS customer_name,
        c.address,
        c.phone
    FROM sales s
    LEFT JOIN customers c
        ON c.id = s.customer_id
    WHERE s.id = ?
");

$stmt->execute([(int)$_GET['id']]);

$sale = $stmt->fetch();

if (!$sale) {
    http_response_code(404);
    exit('Invoice tidak ditemukan.');
}

$itemsStmt = $pdo->prepare("
    SELECT
        si.*,
        p.name,
        p.sku
    FROM sale_items si
    JOIN products p
        ON p.id = si.product_id
    WHERE si.sale_id = ?
");

$itemsStmt->execute([$sale['id']]);
$items = $itemsStmt->fetchAll();
?>
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Invoice <?= e($sale['invoice_no']) ?></title>
<style>
body{font-family:Arial,sans-serif;margin:8px;color:#000;font-size:12px;}
.invoice{width:100%;}
.header{display:flex;justify-content:space-between;margin-bottom:15px;}
.company{width:60%;}
.company h1{margin:0;font-size:28px;}
.invoice-title{text-align:right;width:40%;}
.invoice-title h1{margin:0;font-size:32px;font-weight:bold;}
table{width:100%;border-collapse:collapse;}
th{background:#666;color:#fff;}
th,td{border:1px solid #ccc;padding:4px;}
.total-big{font-size:30px;font-weight:bold;}
.total-box{margin-top:10px;}
@media print{
.no-print{display:none;}
@page{size:A4;margin:5mm;}
}
</style>
</head>
<body>
</body>
</html>