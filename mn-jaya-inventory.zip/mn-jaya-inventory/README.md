# MN. JAYA Sistem Inventori Gudang Grosir dan POS

Aplikasi web lokal/offline untuk inventori, pembelian, kasir, penjualan tempo, pembayaran piutang, cetak struk, dan laporan.

## Teknologi

- PHP 8+
- MySQL / MariaDB
- Apache / XAMPP
- HTML5, CSS3, CSS lokal kompatibel Bootstrap, JavaScript, AJAX

## Struktur Folder

```text
mn-jaya-inventory/
  config/
    config.php
    database.php
  database/
    schema.sql
    seed.sql
  includes/
    auth.php
    helpers.php
    layout.php
  public/
    api/products.php
    assets/css/app.css
    assets/js/app.js
    assets/vendor/bootstrap.min.css
    assets/vendor/bootstrap.bundle.min.js
    dashboard.php
    products.php
    inventory.php
    suppliers.php
    customers.php
    purchases.php
    pos.php
    payments.php
    reports.php
    export.php
    receipt.php
    login.php
    logout.php
    uploads/products/
```

## Modul Utama

- Autentikasi dengan password hash dan akses berbasis role
- Dasbor penjualan hari ini, penjualan bulanan, jumlah produk, stok rendah, dan piutang
- Manajemen produk dengan gambar, SKU, barcode, multi-satuan, multi-harga, stok, dan batas minimum stok
- Inventori untuk stok masuk, stok keluar, penyesuaian, dan riwayat pergerakan stok
- Manajemen pemasok dan alur pesanan pembelian / penerimaan barang
- POS dengan pencarian AJAX, dukungan barcode, keranjang, diskon, pembayaran tunai/transfer/QRIS, jatuh tempo, dan pembuatan faktur
- Database pelanggan dengan level harga, telepon, alamat, limit kredit, dan piutang
- Pembayaran untuk pelunasan penjualan tempo
- Laporan penjualan harian, penjualan bulanan, inventori, laba, stok rendah, piutang, dan pembelian
- Ekspor Excel melalui format `.xls`
- Dukungan cetak/PDF melalui fitur cetak browser
- Layout struk 58mm dan 80mm

## Format Faktur

Faktur penjualan dibuat otomatis dengan format:

```text
INV-YYYYMMDD-00001
```

Contoh:

```text
INV-20260602-00001
```

Nomor urut direset setiap hari dan bertambah dari faktur terakhir pada tanggal tersebut.

## Aturan Stok

Semua stok disimpan dalam satuan dasar produk, biasanya `PCS`.

Contoh:

- `1 Dus = 12 PCS`
- `1 Karton = 24 PCS`

Pembelian dan penjualan mengonversi satuan yang dipilih ke satuan dasar sebelum mengubah stok.

## Catatan Keamanan

- Password menggunakan `password_hash` / `password_verify`.
- Penulisan database menggunakan prepared statement.
- Admin/Manajer mengelola produk, inventori, pembelian, dan laporan.
- Kasir dapat menggunakan POS, pelanggan, dan pembayaran.

Untuk penggunaan produksi, ganti password bawaan, batasi akses phpMyAdmin, aktifkan HTTPS jika memungkinkan, dan lakukan backup database secara berkala.
