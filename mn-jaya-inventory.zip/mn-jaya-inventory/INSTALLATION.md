# Instalasi

## Kebutuhan

- XAMPP dengan Apache dan MySQL/MariaDB
- PHP 8.0 atau lebih baru
- Browser di komputer server atau jaringan lokal

## Langkah Instalasi

1. Salin folder `mn-jaya-inventory` ke folder XAMPP `htdocs`.
2. Jalankan Apache dan MySQL dari XAMPP Control Panel.
3. Buka phpMyAdmin.
4. Impor `database/schema.sql`.
5. Impor `database/seed.sql`.
6. Ubah `config/config.php` jika username atau password MySQL berbeda.
7. Buka `http://localhost/mn-jaya-inventory/public`.

## Akses LAN

Di komputer server, cari alamat IP lokal, lalu buka:

`http://IP-SERVER/mn-jaya-inventory/public`

Pastikan Windows Firewall mengizinkan Apache untuk jaringan lokal.

## Pengguna Bawaan

Semua kata sandi bawaan adalah `password`.

- Admin: `admin`
- Manajer: `manager`
- Kasir: `cashier`

Ganti kata sandi bawaan sebelum digunakan secara produksi.

## Cetak Struk

Struk dicetak melalui browser. Ubah `receipt_width` pada tabel `settings`:

- `58` untuk kertas thermal 58mm
- `80` untuk kertas thermal 80mm

Gunakan dialog cetak browser dan pilih printer thermal.
